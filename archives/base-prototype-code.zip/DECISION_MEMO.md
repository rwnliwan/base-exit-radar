# Decision memo — Prototipe kecil Base Stocks Maxxing

Tanggal: 22 November 2026 (WITA). Status: **gate §7 lolos 9/9**, prototipe
lokal/offline selesai dan terverifikasi chief. Memo ini untuk keputusan ACC
Alex (Septian) atas fase berikutnya. **Lolos gate bukan izin otomatis
melanjutkan.**

## Ringkasan satu kalimat

Plumbing alert end-to-end terbukti jalan (9/9), tapi prototipe ini masih
**monitor indikatif** — belum ada bukti exit (sell quote) — sehingga
pembeda produk ("bisa keluar, dengan bukti harga seperti apa?") **belum
terbukti**.

## Apa yang lulus

- **Gate §7: 9/9 PASS** (terverifikasi chief dengan `python3 gate.py`,
  22 Nov ~17:43 WITA). Happy path 10/10, NAV weekend 8/8, multiplier 4/4,
  liquidity vs exit 5/5, sisanya PASS dengan kriteria yang tercatat di
  `out/gate_log.md` + `out/gate_results.json`.
- **Ingest live berfungsi.** NVDAc + AAPLc teridentifikasi via Coinbase API
  (tanpa key); pool nyata terkonfirmasi (Aerodrome Slipstream); proxy
  underlying `xyz:NVDA` / `xyz:AAPL` ditemukan di Hyperliquid
  (`metaAndAssetCtxs`). Respons mentah tersimpan di `evidence/`.
- **Keputusan jujur.** Live run: NVDAc → WATCH, AAPLc → WATCH. Keduanya
  menahan seluruh alokasi simulasi di cash (`cash_weight: 1.0`,
  `weights: {}`) karena tidak ada bukti exit. Tidak ada usulan beli palsu.
- **Koreksi Instinct §3 diterapkan dan terbukti:** NAV tidak dikali multiplier
  lagi (tes multiplier 4/4); dua agregator baca pool sama = satu pool
  (tes coverage); gap DEX-vs-NAV hanya deskripsi berlabel (bukan mispricing);
  TVL tidak dipakai sebagai bukti exit (tes liquidity vs exit); proxy
  dilabeli terpisah dan tidak memicu alert token-exit (tes proxy).
- **Replay + idempotensi berfungsi.** Snapshot publik dapat di-replay
  (`run.py --replay`), alert tidak terduplikasi, alert replay berlabel
  `TEST/REPLAY`. Bug replay (`KeyError: '_token_ok'`) ditemukan saat
  verifikasi chief dan sudah diperbaiki (lihat `DESIGN.md` §9).
- **Batas fase dipegang.** Tidak ada onchain, tidak ada deploy, tidak ada
  ubah Radar live, tidak ada kirim alert ke Telegram produksi, tidak ada
  pendaftaran kompetisi. Semua lokal/offline.

## Apa yang gagal / terbatas (jujur)

- **Tidak ada sell-quote adapter → tidak ada bukti exit.** Ini keterbatasan
  terbesar dan struktural, bukan bug. Status exit selalu
  `indicative_only/exit_quality_unverified`. Prototipe ini memonitor kondisi
  indikatif; **tidak cukup untuk mengklaim exit-quality atau mengizinkan
  usulan beli berbasis bukti exit.** (Sesuai §7 brief: ketiadaan executable
  quote tidak menggagalkan demonstrasi plumbing, tapi membatasi hasil menjadi
  monitor indikatif.)
- **Registry pause tidak dibaca.** `registry_pause_status: unknown`
  (butuh RPC read-only; di luar scope adapter HTTP). Bila registry ternyata
  pause, prototipe tidak akan tahu.
- **Coverage lintas-venue tipis.** Efektif 1 pool dominan per token
  (Aerodrome). Median dari 2 observasi rapuh. Belum ada sensus venue lengkap.
- **Threshold belum tervalidasi.** DEV_WATCH 2% / DEV_ABSTAIN 5% adalah
  tebakan awal versioned — tidak ada data false-positive / false-negative.
  Kalibrasi butuh seri historis + definisi outcome.
- **Tidak ada bukti kualitas prediktif.** Lolos test teknis bukan bukti
  kualitas prediktif atau keuntungan. Tidak ada backtest, tidak ada outcome.
- **PoR + redemption tetap `unknown`.** Tidak ada sumber otomatis. Ini
  batas jujur, bukan kegagalan — tapi artinya skor "exit-ability setara
  Solana" tidak bisa dibangun dari prototipe ini.

## Apa yang masih unknown

- Apakah sell-quote adapter feasible untuk token ini (quoter Aerodrome
  Slipstream / API quoter lain)? Belum diteliti. Ini penentu apakah
  pembeda produk bisa dibuktikan.
- Apakah registry pause bisa dibaca via RPC publik Base (read-only)?
  Belum dicoba.
- Apakah ada venue/pool lain yang material di luar Aerodrome? Belum disensus.
- Apakah rubrik kompetisi menghargai paper-portfolio / testnet? Masih
  terbuka (bukan diselesaikan gate teknis ini).
- Apakah bobot traction 50/25/25 adalah rules resmi? Tidak terverifikasi —
  jangan diasumsikan.

## Estimasi sisa pekerjaan (berdasarkan source yang benar-benar diperiksa)

| Pekerjaan | Estimasi | Keterangan |
|---|---|---|
| Riset + bangun sell-quote adapter (read-only) | 0,5–1 hari | Tentukan quoter (Aerodrome Slipstream / API). Bila quoter tidak ada / tidak bisa dipakai read-only → blocker, STOP untuk klaim exit-quality. |
| Baca registry pause via RPC publik Base | 1–2 jam | Butuh endpoint RPC publik read-only. |
| Sensus venue/pool tambahan | 2–3 jam | Cek DEX lain di Base untuk NVDAc/AAPLc. |
| Kalibrasi threshold (historis) | Di luar jendela | Butuh seri historis + definisi outcome; tidak bisa selesai sebelum 28 Nov secara kredibel. Threshold tetap eksperimen. |
| Desain hash registry Base Sepolia (§8) | Sudah ada di `DESIGN.md` §8 | Spesifikasi saja; deploy menunggu gate + ACC. |
| QA + submission (bila lanjut) | 1–3 Des QA, 4 Des submit (buffer) | Hanya sesudah gate + ACC eksplisit. Deadline resmi 5 Des 23:59 UTC = 6 Des 07:59 WITA. |

## Pilihan: GO terbatas atau STOP

**Opsi A — GO TERBATAS (rekomendasi chief).**
Lanjutkan **hanya** ke satu langkah berikutnya yang terdefinisi: riset +
bangun sell-quote adapter + baca registry pause, lalu jalankan ulang gate.
Batas waktu: selesai sebelum review 28 Nov. **Stop condition keras:** bila
quoter terbukti tidak feasible (tidak ada quoter read-only yang bisa
dipakai), berhenti — jangan klaim exit-quality dari monitor indikatif.
Bila quoter jalan, prototipe menjadi monitor bukti-exit yang jujur, dan
keputusan lanjut ke QA/submission dibahas lagi dengan ACC eksplisit.

Alasan: plumbing sudah terbukti (9/9). Quoter adalah satu-satunya blocker
untuk pembeda produk. Langkahnya kecil dan terdefinisi. Risiko terbatas
(kill-switch 30 Nov tetap berlaku).

**Opsi B — STOP.**
Berhenti di sini. Prototipe disimpan sebagai bukti teknis (plumbing +
gate) tanpa dilanjutkan ke kompetisi. Alasan yang sah: sisa waktu
(8 hari ke kill-switch 30 Nov) tidak cukup untuk quoter + kalibrasi +
onchain + QA + submission secara kredibel; atau Septian menilai monitor
indikatif saja tidak cukup kuat sebagai entry kompetisi.

**Yang tidak direkomendasikan:** lanjut ke build penuh / submission dengan
menganggap monitor indikatif ini sudah membuktikan exit-quality. Itu
overclaim — bertentangan dengan brief Instinct §7 dan dengan kejujuran
produk ("bisa keluar, dengan bukti harga seperti apa?").

## Keputusan yang diminta dari Alex

Pilih **Opsi A (GO terbatas, ke quoter + registry)** atau **Opsi B (STOP)**.
Bila Opsi A, chief lanjut ke riset quoter. Bila Opsi B, prototipe diarsipkan
dan tidak ada pekerjaan Base lebih lanjut sebelum keputusan baru.
