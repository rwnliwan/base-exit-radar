"""Gerbang alert end-to-end (§7 brief Instinct) — 9 tes.

Setiap tes memakai snapshot nyata (fixtures/snapshot_live_20261122_*.json)
atau fixture yang dimodifikasi dari snapshot itu (disimpan di fixtures/).
Replay memakai mode TEST/REPLAY agar alert sintetis tidak dikira kejadian
pasar live. Alert dedup memakai seen file SEMENTARA (bukan alerts_seen.json
produksi lokal) agar tes tidak mencemari dedup run live.

Penggunaan:
  python3 gate.py
Output:
  out/gate_results.json   (hasil per tes: expected vs actual, pass/fail)
  out/gate_log.md         (log test yang bisa dibaca manusia)

Kriteria lulus per tes ada di docstring masing-masing tes (dari §7 brief).
"""

import copy
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
import pipeline

BASE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(BASE, "fixtures")
OUT = os.path.join(BASE, "out")
SEEN_TEST = os.path.join(OUT, "alerts_seen_gate_test.json")


def _load_fixture(name):
    with open(os.path.join(FIX, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _save_fixture(name, obj):
    p = os.path.join(FIX, name)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")
    return p


def _reassess(snap):
    """Jalankan ulang assess+decide+explain dari snapshot (tanpa fetch)."""
    snap = pipeline.assess_snapshot(snap)
    snap = pipeline.decide(snap)
    snap = pipeline.explain(snap)
    return snap


def _result(name, expected, actual, passed, details=""):
    return {"test": name, "expected": expected, "actual": actual,
            "pass": bool(passed), "details": details}


# ------------------------------------------------------------------- tes 1
def test_happy_path():
    """Dua token resmi terbaca, identitas tepat, nilai/timestamp/source
    tersimpan. Keputusan policy bisa dijelaskan sampai ke input."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    checks = []
    checks.append(("chain==base", snap["asset"]["chain"] == "base"))
    checks.append(("contract==expected",
                   snap["asset"]["token_address"].lower()
                   == config.TOKENS["NVDAc"]["token_address"].lower()))
    checks.append(("symbol==NVDAc", snap["asset"]["symbol"] == "NVDAc"))
    checks.append(("nav_price>0",
                   snap["reference"]["nav_price"] is not None
                   and snap["reference"]["nav_price"] > 0))
    checks.append(("nav_updated_at present",
                   snap["reference"]["nav_price_updated_at"] is not None))
    checks.append(("fetched_at present", bool(snap["fetched_at"])))
    checks.append(("pools>=min",
                   snap["coverage"]["independent_pool_count"]
                   >= config.MIN_INDEPENDENT_POOLS))
    checks.append(("decision in {ABSTAIN,WATCH,PAPER_PROPOSAL}",
                   snap["decision"] in ("ABSTAIN", "WATCH", "PAPER_PROPOSAL")))
    checks.append(("explanation non-empty",
                   isinstance(snap.get("explanation"), str)
                   and len(snap["explanation"]) > 50))
    checks.append(("explanation mentions contract",
                   snap["asset"]["token_address"] in snap["explanation"]))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "happy_path",
        "identity correct, values/timestamps/sources saved, decision explainable",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "snapshot=%s decision=%s" % (snap["snapshot_id"], snap["decision"]))


# ------------------------------------------------------------------- tes 2
def test_controlled_trigger():
    """Ubah satu fixture kondisi DEX secara eksplisit. Seluruh pipeline
    menghasilkan satu alert lokal TEST/REPLAY. Jangan klaim trigger sintetis
    sebagai alert pasar nyata."""
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = copy.deepcopy(base)
    # Ubah SATU pool (teratas by liquidity) agar harganya +8% di atas median.
    # Itu melewati DEV_ABSTAIN_PCT (5%) -> ABSTAIN (dex_deviation_extreme).
    median = snap["assessment"]["layer_a"]["median_price_usd"]
    top = snap["pools"][0]
    old_price = top["indicative_price_usd"]
    top["indicative_price_usd"] = round(median * 1.08, 4)
    _save_fixture("fixture_trigger_deviation.json", snap)
    snap = _reassess(snap)
    # Emit alert TEST/REPLAY (seen file sementara).
    if os.path.exists(SEEN_TEST):
        os.remove(SEEN_TEST)
    res = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    expected = ("decision=ABSTAIN reason=dex_deviation_extreme, "
                "one TEST/REPLAY alert emitted")
    actual = ("decision=%s reasons=%s alert_duplicate=%s mode=%s"
              % (snap["decision"], snap["decision_reasons"],
                 res["duplicate"], res["mode"]))
    passed = (snap["decision"] == "ABSTAIN"
              and "dex_deviation_extreme" in snap["decision_reasons"]
              and not res["duplicate"] and res["mode"] == "TEST/REPLAY")
    return _result("controlled_trigger", expected, actual, passed,
                   "input change: pool %s price %.4f -> %.4f (+8%% vs median %.2f); "
                   "rule_version=%s; alert_id=%s"
                   % (top["pool_address"], old_price,
                      top["indicative_price_usd"], median,
                      snap["policy_version"], res["alert_id"]))


# ------------------------------------------------------------------- tes 3
def test_nav_weekend():
    """Replay nilai NAV Jumat dan snapshot Minggu. NAV tampil sebagai last
    published reference + age/off-hours, tidak dipakai sebagai live-price
    alarm atau dasar mispricing."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    ref = snap["reference"]
    gap = snap["assessment"]["layer_a"]["nav_gap_pct_labeled"]
    checks = []
    checks.append(("nav_updated_at is Friday",
                   ref["nav_price_updated_at"].startswith("2026-11-20")))
    checks.append(("fetched_at is Sunday",
                   snap["fetched_at"].startswith("2026-11-22")))
    checks.append(("session_status==off_hours",
                   ref["session_status"] == "off_hours"))
    checks.append(("nav age > 24h", (ref["age_seconds"] or 0) > 24 * 3600))
    checks.append(("nav_gap is labeled description",
                   gap is not None
                   and gap["label"] == "dex_median_vs_last_published_nav"
                   and "cause_and_exploitability_unproven" in gap["note"]))
    checks.append(("nav_gap not labeled mispricing/arbitrage",
                   "mispricing" not in json.dumps(gap).lower()
                   or "unproven" in json.dumps(gap).lower()))
    # NAV gap TIDAK memicu reason code alert sendiri.
    checks.append(("no nav_gap reason code",
                   not any("nav_gap" in c or "mispric" in c
                           for c in snap["decision_reasons"])))
    # NAV tidak dikali multiplier (lihat juga tes 4).
    checks.append(("nav_price is raw (not multiplied)",
                   abs(ref["nav_price"] - 129.82480034) < 1e-9))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "nav_weekend",
        "NAV shown as last published reference + age/off-hours; not a live alarm",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "nav_age_seconds=%s nav_gap_pct=%s"
        % (ref["age_seconds"],
           (gap or {}).get("value_pct")))


# ------------------------------------------------------------------- tes 4
def test_multiplier():
    """Buktikan NAV tidak dikalikan lagi. Raw share conversion memakai
    multiplier yang sesuai waktu/unit."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    ref = snap["reference"]
    mult = snap["multiplier"]["value"]
    raw_nav = 129.82480034  # nilai mentah dari API Coinbase (evidence)
    checks = []
    # (a) nav_price yang disimpan == nilai mentah API (tidak dikali).
    checks.append(("stored nav == raw API nav",
                   abs(ref["nav_price"] - raw_nav) < 1e-9))
    # (b) Bila dikali multiplier, hasilnya BERBEDA -> bukti tidak dikali.
    multiplied = raw_nav * mult
    checks.append(("nav x multiplier != stored nav (proves not multiplied)",
                   abs(multiplied - ref["nav_price"]) > 0.01))
    # (c) Round-trip raw share: raw_share = nav / multiplier; lalu
    #     raw_share x multiplier == nav (konsisten, memakai multiplier
    #     yang efektif saat itu, bukan multiplier hari ini untuk seluruh seri).
    raw_share = raw_nav / mult
    checks.append(("raw_share x multiplier == nav (round-trip)",
                   abs(raw_share * mult - raw_nav) < 1e-9))
    # (d) Multiplier tercatat terpisah (untuk referensi), bukan diterapkan
    #     ke nav_price.
    checks.append(("multiplier recorded separately",
                   mult is not None and mult > 1.0))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "multiplier",
        "NAV not multiplied again; raw share conversion uses effective multiplier",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "nav=%.8f multiplier=%.16f nav_x_mult=%.8f raw_share=%.8f"
        % (raw_nav, mult, multiplied, raw_share))


# ------------------------------------------------------------------- tes 5
def test_missing_stale():
    """Putuskan sumber atau buat data basi. Usulan baru diblokir/ABSTAIN
    sesuai policy; tidak ada risiko nol palsu. Freshness gate quote,
    observasi DEX, dan NAV terpisah."""
    # (a) Sumber DEX putus: pools kosong.
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    s1 = copy.deepcopy(base)
    s1["pools"] = []
    s1["coverage"]["independent_pool_count"] = 0
    s1["coverage"]["independent_venue_count"] = 0
    _save_fixture("fixture_missing_pools.json", s1)
    s1 = _reassess(s1)
    a_ok = (s1["decision"] == "ABSTAIN"
            and "insufficient_cross_venue_coverage" in s1["decision_reasons"]
            and s1["assessment"]["layer_a"]["median_price_usd"] is None)
    # (b) NAV sangat basi (7 hari).
    s2 = copy.deepcopy(base)
    s2["reference"]["nav_price_updated_at"] = "2026-11-15T23:42:40Z"
    s2["reference"]["age_seconds"] = 7 * 24 * 3600
    s2["reference"]["session_status"] = "off_hours"
    _save_fixture("fixture_stale_nav.json", s2)
    s2 = _reassess(s2)
    b_ok = ("nav_stale_off_hours" in s2["decision_reasons"]
            and s2["decision"] in ("ABSTAIN", "WATCH")
            and s2["decision"] != "PAPER_PROPOSAL")
    # (c) Freshness gate terpisah: quote / DEX / NAV masing-masing tercatat.
    c_ok = (s1["assessment"]["layer_b"]["status"]
            == "indicative_only/exit_quality_unverified")
    passed = a_ok and b_ok and c_ok
    return _result(
        "missing_stale",
        "missing source -> ABSTAIN (no zero-risk); stale NAV flagged; gates separate",
        "missing_pools: decision=%s (expect ABSTAIN) ok=%s; "
        "stale_nav: decision=%s codes=%s ok=%s; gates_separate ok=%s"
        % (s1["decision"], a_ok, s2["decision"], s2["decision_reasons"],
           b_ok, c_ok),
        passed,
        "missing pools median=None (not 0); stale NAV age=604800s flagged")


# ------------------------------------------------------------------- tes 6
def test_coverage():
    """Dua agregator untuk satu pool dihitung satu pool. Satu venue tidak
    menghasilkan cross-venue confidence palsu."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    # (a) Pool teratas punya cross_check GeckoTerminal (pool yang sama).
    top = snap["pools"][0]
    a_ok = ("cross_check" in top
            and top["cross_check"].get("note")
            == "same_pool_not_independent_venue")
    # Jumlah pool di pools[] == independent_pool_count (tidak double-count).
    a_ok = a_ok and (len(snap["pools"])
                     == snap["coverage"]["independent_pool_count"])
    # (b) Hanya satu pool valid -> ABSTAIN, median None (bukan nol).
    s2 = copy.deepcopy(snap)
    s2["pools"] = [copy.deepcopy(s2["pools"][0])]
    s2["coverage"]["independent_pool_count"] = 1
    s2["coverage"]["independent_venue_count"] = 1
    _save_fixture("fixture_single_pool.json", s2)
    s2 = _reassess(s2)
    b_ok = (s2["decision"] == "ABSTAIN"
            and "insufficient_cross_venue_coverage" in s2["decision_reasons"]
            and s2["assessment"]["layer_a"]["median_price_usd"] is None)
    return _result(
        "coverage",
        "two aggregators one pool = one pool; one venue -> no false confidence",
        "cross_check_same_pool ok=%s; single_pool decision=%s (expect ABSTAIN) "
        "median=None ok=%s" % (a_ok, s2["decision"], b_ok),
        bool(a_ok and b_ok),
        "live pools=%d venues=%d; single-pool fixture median=None"
        % (snap["coverage"]["independent_pool_count"],
           snap["coverage"]["independent_venue_count"]))


# ------------------------------------------------------------------- tes 7
def test_proxy():
    """Funding ekstrem atau perubahan OI saja tidak memicu klaim token-exit.
    Label proxy bertahan sampai payload alert/paper proposal. Histori belum
    cukup menghasilkan null, bukan perubahan 24h rekaan."""
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = copy.deepcopy(base)
    # Funding ekstrem (5%/jam) + OI raksasa pada proxy.
    snap["underlying_proxy"]["funding_raw"] = 0.05
    snap["underlying_proxy"]["open_interest_raw"] = 999999999.0
    _save_fixture("fixture_proxy_extreme.json", snap)
    snap = _reassess(snap)
    if os.path.exists(SEEN_TEST):
        os.remove(SEEN_TEST)
    res = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    # Keputusan TIDAK berubah karena proxy saja (tetap WATCH; bukan ABSTAIN
    # karena proxy, bukan PAPER_PROPOSAL).
    a_ok = (snap["decision"] == "WATCH"
            and "no_exit_quote_adapter" in snap["decision_reasons"])
    # Label proxy bertahan sampai payload alert.
    b_ok = (not res["duplicate"]
            and res["payload"]["proxy_label"]
            == "UNDERLYING EQUITY PERP PROXY")
    # OI change 24h = null (insufficient_history), bukan 0% / rekaan.
    c_ok = (snap["underlying_proxy"]["oi_change_24h"] is None
            and snap["underlying_proxy"]["oi_change_24h_basis"]
            == "insufficient_history_no_baseline")
    return _result(
        "proxy",
        "extreme funding/OI alone does not trigger token-exit claim; label persists; OI change null",
        "decision=%s (expect WATCH) ok=%s; alert proxy_label ok=%s; "
        "oi_change_24h=None ok=%s" % (snap["decision"], a_ok, b_ok, c_ok),
        bool(a_ok and b_ok and c_ok),
        "funding set to 0.05 (5%%/h); decision unchanged by proxy alone")


# ------------------------------------------------------------------- tes 8
def test_liquidity_vs_exit():
    """TVL besar tanpa sell quote tetap exit_quality_unverified; tidak ada
    klaim bisa menjual nominal tertentu."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    top_liq = snap["pools"][0]["liquidity_usd"] if snap["pools"] else 0
    checks = []
    checks.append(("top pool liquidity is large (>$1M)",
                   top_liq > 1_000_000))
    checks.append(("exit_quote is None", snap["exit_quote"] is None))
    checks.append(("layer_b status indicative_only",
                   snap["assessment"]["layer_b"]["status"]
                   == "indicative_only/exit_quality_unverified"))
    checks.append(("decision is not PAPER_PROPOSAL",
                   snap["decision"] != "PAPER_PROPOSAL"))
    # Tidak ada klaim "bisa menjual nominal X" di explanation/paper record.
    rec = pipeline.paper_record(snap)
    blob = json.dumps(rec) + snap["explanation"]
    checks.append(("no sell-nominal claim in paper record/explanation",
                   "can sell" not in blob.lower()
                   and "bisa menjual" not in blob.lower()))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "liquidity_vs_exit",
        "large TVL without sell quote stays exit_quality_unverified; no sell claim",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "top_pool_liquidity_usd=%.2f decision=%s" % (top_liq, snap["decision"]))


# ------------------------------------------------------------------- tes 9
def test_idempotency():
    """Replay snapshot/rule sama tidak menduplikasi alert. Input buruk
    menghasilkan error terstruktur, bukan output sukses kosong."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    if os.path.exists(SEEN_TEST):
        os.remove(SEEN_TEST)
    r1 = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    r2 = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    a_ok = (not r1["duplicate"] and r2["duplicate"]
            and r1["alert_id"] == r2["alert_id"])
    # Input buruk -> error terstruktur (exception), bukan sukses kosong.
    try:
        pipeline.assess_snapshot({})
        b_ok = False
        b_detail = "assess_snapshot({}) returned success (BAD: empty success)"
    except (KeyError, TypeError, AttributeError) as e:
        b_ok = True
        b_detail = "assess_snapshot({}) raised %s (structured error, not empty success)" % type(e).__name__
    return _result(
        "idempotency",
        "same snapshot/rule replay does not duplicate alert; bad input errors",
        "first emit duplicate=%s, second emit duplicate=%s, same id=%s; "
        "bad input: %s" % (r1["duplicate"], r2["duplicate"],
                           r1["alert_id"] == r2["alert_id"], b_detail),
        bool(a_ok and b_ok),
        "alert_id=%s" % r1["alert_id"])


# -------------------------------------------------------------------- main
TESTS = [
    ("happy_path", test_happy_path),
    ("controlled_trigger", test_controlled_trigger),
    ("nav_weekend", test_nav_weekend),
    ("multiplier", test_multiplier),
    ("missing_stale", test_missing_stale),
    ("coverage", test_coverage),
    ("proxy", test_proxy),
    ("liquidity_vs_exit", test_liquidity_vs_exit),
    ("idempotency", test_idempotency),
]


def main():
    os.makedirs(OUT, exist_ok=True)
    results = []
    for name, fn in TESTS:
        try:
            r = fn()
        except Exception as e:  # noqa: BLE001 - satu tes gagal != crash harness
            r = _result(name, "see test docstring",
                        "EXCEPTION %s: %s" % (type(e).__name__, e), False,
                        "test raised; harness continued")
        results.append(r)
        mark = "PASS" if r["pass"] else "FAIL"
        print("[%s] %s: %s" % (mark, r["test"], r["actual"]))
    n_pass = sum(1 for r in results if r["pass"])
    summary = {"gate": "base-prototype §7", "policy_version": config.POLICY_VERSION,
               "methodology_version": config.METHODOLOGY_VERSION,
               "schema_version": config.SCHEMA_VERSION,
               "total": len(results), "passed": n_pass,
               "failed": len(results) - n_pass,
               "results": results}
    with open(os.path.join(OUT, "gate_results.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, sort_keys=True)
        f.write("\n")
    lines = ["# Gate §7 — hasil test (Base prototype)",
             "",
             "Policy: %s | Method: %s | Schema: %s" % (
                 config.POLICY_VERSION, config.METHODOLOGY_VERSION,
                 config.SCHEMA_VERSION),
             "",
             "Hasil: **%d/%d PASS**." % (n_pass, len(results)),
             "",
             "| Tes | Hasil | Expected | Actual |",
             "|-----|-------|----------|--------|"]
    for r in results:
        lines.append("| %s | %s | %s | %s |" % (
            r["test"], "PASS" if r["pass"] else "FAIL",
            r["expected"], r["actual"]))
    lines.append("")
    lines.append("Detail per tes (termasuk fixture yang dimodifikasi) ada di "
                "`gate_results.json` dan `fixtures/`. Replay memakai mode "
                "TEST/REPLAY; alert sintetis bukan kejadian pasar live.")
    with open(os.path.join(OUT, "gate_log.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("Gate: %d/%d PASS. Hasil di out/gate_results.json + out/gate_log.md."
          % (n_pass, len(results)))
    return 0 if n_pass == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
