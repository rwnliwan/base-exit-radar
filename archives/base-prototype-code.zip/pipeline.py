"""Pipeline prototipe Base (ingest -> validate -> assess -> decide -> explain
-> alert -> paper record). Lokal/offline. Tidak mengubah Radar produksi.

Mengikuti brief Instinct §4 (alur), §5 (kontrak data), §6 (redesign Exit
Score, bukan port). Tidak mewarisi bobot / min-3-dari-5 / threshold 70 /
cutoffs Solana. Tidak menampilkan score 0-100 seolah sudah dikalibrasi.

KOREKSI YANG MENGIKAT (§3) — diterapkan di seluruh pipeline:
1. nav_price SUDAH multiplier-adjusted. JANGAN dikali multiplier lagi.
   (Rumus token = equity x multiplier hanya untuk harga saham MENTAH.)
2. Gap DEX-vs-NAV beku = deskripsi berlabel saja. Bukan diskon/mispricing/
   arbitrase/tidak-bisa-dieksploitasi/pasti-false-positive.
3. TVL/reserve/likuiditas BUKAN executable depth. Hanya filter kelayakan.
4. Redemption: desain mengasumsikan TIDAK ADA jalur permissionless retail.
5. PoR: tidak ada sumber otomatis. Hanya catatan manual atau `unknown`.
6. Dua agregator baca pool sama = SATU pool (dedup by pool_address).
7. Proxy underlying (xyz:NVDA/xyz:AAPL) = UNDERLYING EQUITY PERP PROXY.
   Bukan ukuran exit-risk token. Tidak memicu alert token-exit.
"""

import hashlib
import json
import math
import re
from datetime import datetime, timezone

import adapter
import config

# ------------------------------------------------------------------ helpers
_ADDR_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")


def _is_address(s):
    return isinstance(s, str) and bool(_ADDR_RE.match(s))


def _to_float(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _parse_ts(s):
    """Parse ISO-8601 ke datetime (UTC). Kembalikan None bila tak valid."""
    if not isinstance(s, str):
        return None
    try:
        t = s.replace("Z", "+00:00")
        dt = datetime.fromisoformat(t)
        return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _now():
    return datetime.now(timezone.utc)


def _iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def _short_hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


# ------------------------------------------------------------------ ingest
def ingest_token(symbol):
    """Ingest satu token: Coinbase record + pool DexScreener + cross-check
    GeckoTerminal + proxy Hyperliquid (dex baseline "xyz").

    Kembalikan (snapshot_partial, fetch_meta). `snapshot_partial` berisi
    data mentah + fetched_at per sumber. Validasi dilakukan di build_snapshot.
    Tidak ada yang di-hard-code dari snapshot harga sebelumnya.
    """
    tok = config.TOKENS[symbol]
    fetched_at = _now()
    meta = {"fetched_at": _iso(fetched_at), "sources": {}, "errors": {}}

    cb = adapter.fetch_coinbase_tokens()
    meta["sources"]["coinbase"] = cb["source"]
    if not cb["ok"]:
        meta["errors"]["coinbase"] = cb["error"]
    record = adapter.find_token(cb["tokens"], tok["token_address"]) if cb["ok"] else None

    ds = adapter.fetch_dexscreener_pools(tok["token_address"])
    meta["sources"]["dexscreener"] = ds["source"]
    if not ds["ok"]:
        meta["errors"]["dexscreener"] = ds["error"]

    # Cross-check GeckoTerminal HANYA untuk pool teratas (by liquidity).
    # Ini pool yang SAMA, bukan venue independen (dedup by pool_address).
    gt = {"ok": False, "pool": None, "fetched_at": _iso(fetched_at),
          "source": None, "error": None}
    top_pool = None
    if ds["ok"] and ds["pairs"]:
        def _liq(p):
            v = _to_float((p.get("liquidity") or {}).get("usd"))
            return v if v is not None else -1.0
        cands = [p for p in ds["pairs"]
                 if _is_address(p.get("pairAddress") or "")]
        if cands:
            top_pool = max(cands, key=_liq).get("pairAddress")
    if top_pool:
        gt = adapter.fetch_geckoterminal_pool(top_pool)
        meta["sources"]["geckoterminal"] = gt["source"]
        if not gt["ok"]:
            meta["errors"]["geckoterminal"] = gt["error"]

    hl = adapter.fetch_hyperliquid_proxy(config.PROXY_BASELINE_DEX)
    meta["sources"]["hyperliquid"] = hl["source"]
    if not hl["ok"]:
        meta["errors"]["hyperliquid"] = hl["error"]

    return {
        "symbol": symbol,
        "token_cfg": tok,
        "coinbase_record": record,
        "dexscreener_pairs": ds["pairs"] if ds["ok"] else [],
        "geckoterminal_pool": gt["pool"] if gt["ok"] else None,
        "geckoterminal_pool_address": top_pool,
        "hyperliquid": hl["instruments"] if hl["ok"] else {},
        "meta": meta,
    }


# ---------------------------------------------------------------- validate
def build_snapshot(symbol, ingested=None):
    """Bangun snapshot (§5) dari hasil ingest + validasi.

    Error sumber -> `unknown`, BUKAN nol risiko. Nilai yang gagal validasi
    ditolak dan dicatat di coverage.rejected_observations / missing_fields.
    """
    tok = config.TOKENS[symbol]
    if ingested is None:
        ingested = ingest_token(symbol)
    fetched = _parse_ts(ingested["meta"]["fetched_at"]) or _now()
    missing = []
    rejected = []

    # ---- asset: kunci identitas chain + contract (bukan ticker saja)
    asset = {"chain": config.CHAIN, "token_address": tok["token_address"],
             "symbol": symbol, "decimals": tok["decimals"]}

    # ---- reference: nav_price APA ADANYA (sudah multiplier-adjusted).
    # JANGAN dikali multiplier lagi.
    rec = ingested["coinbase_record"]
    reference = {"nav_price": None, "nav_price_updated_at": None,
                 "age_seconds": None, "session_status": "unknown",
                 "session_status_basis": "not_determined",
                 "registry_pause_status": "unknown",
                 "source": config.COINBASE_API_URL}
    multiplier = {"value": None, "observed_at": None,
                  "source": config.COINBASE_API_URL}
    token_ok = False
    if rec is None:
        missing.append("coinbase_record")
    else:
        if (rec.get("contract_address") or "").lower() != tok["token_address"].lower():
            rejected.append({"field": "contract_address",
                             "reason": "mismatch_expected"})
        elif (rec.get("symbol") or "") != symbol:
            rejected.append({"field": "symbol", "reason": "mismatch_expected"})
        else:
            token_ok = True
        nav = _to_float(rec.get("nav_price"))
        if nav is None or nav <= 0:
            missing.append("nav_price")
            rejected.append({"field": "nav_price", "reason": "nonpositive_or_missing"})
        else:
            reference["nav_price"] = nav
        nav_ts = _parse_ts(rec.get("nav_price_updated_at"))
        if nav_ts is None:
            missing.append("nav_price_updated_at")
        else:
            if (nav_ts - fetched).total_seconds() > config.MAX_FUTURE_SKEW_SEC:
                rejected.append({"field": "nav_price_updated_at",
                                 "reason": "unreasonable_future_timestamp"})
                missing.append("nav_price_updated_at")
            else:
                reference["nav_price_updated_at"] = _iso(nav_ts)
                reference["age_seconds"] = int((fetched - nav_ts).total_seconds())
                # session_status: dari umur NAV (feed 24/5, heartbeat 24 jam).
                # Bukan tebakan dari weekday saja; alasan dicatat di basis.
                age_h = reference["age_seconds"] / 3600.0
                if age_h <= config.NAV_STALE_HOURS:
                    reference["session_status"] = "active"
                    reference["session_status_basis"] = (
                        "nav_age_%.1fh_within_24h_heartbeat" % age_h)
                else:
                    reference["session_status"] = "off_hours"
                    reference["session_status_basis"] = (
                        "nav_age_%.1fh_exceeds_24h_heartbeat_feed_holding_last_close"
                        % age_h)
        mult = _to_float(rec.get("multiplier"))
        if mult is None or mult <= 0:
            missing.append("multiplier")
        else:
            multiplier["value"] = mult
            multiplier["observed_at"] = reference["nav_price_updated_at"]
        # registry_pause_status: TIDAK dibaca (butuh RPC). Tetap `unknown`.
        # Ketiadaan field tidak membuktikan semua fungsi aktif (brief §5).

    # ---- pools: observasi independen, dedup by pool_address.
    # Dua agregator baca pool sama = SATU pool (bukan dua venue).
    pools = []
    seen_pool = set()
    for p in ingested["dexscreener_pairs"]:
        addr = (p.get("pairAddress") or "").lower()
        if not _is_address(p.get("pairAddress") or ""):
            rejected.append({"field": "pairAddress", "reason": "invalid_address"})
            continue
        if addr in seen_pool:
            continue
        seen_pool.add(addr)
        if (p.get("chainId") or "") != "base":
            rejected.append({"pool": addr, "reason": "chain_not_base"})
            continue
        base_addr = (p.get("baseToken") or {}).get("address") or ""
        if base_addr.lower() != tok["token_address"].lower():
            rejected.append({"pool": addr, "reason": "base_token_mismatch"})
            continue
        dex = p.get("dexId") or ""
        quote = (p.get("quoteToken") or {}).get("symbol") or ""
        price = _to_float(p.get("priceUsd"))
        liq = _to_float((p.get("liquidity") or {}).get("usd"))
        if not dex or not quote:
            rejected.append({"pool": addr, "reason": "missing_dex_or_quote"})
            continue
        if price is None or price <= 0:
            rejected.append({"pool": addr, "reason": "price_nonpositive_or_missing"})
            continue
        if liq is None or liq <= 0:
            rejected.append({"pool": addr, "reason": "liquidity_nonpositive_or_missing"})
            continue
        obs = {"pool_address": p.get("pairAddress"), "dex": dex,
               "quote_asset": quote, "indicative_price_usd": price,
               "liquidity_usd": liq,
               # DexScreener tidak memberi timestamp harga -> `unknown`.
               # Jangan klaim harga fresh hanya karena fetch sukses (§5).
               "source_updated_at": "unknown",
               "fetched_at": ingested["meta"]["fetched_at"],
               "source": ingested["meta"]["sources"].get("dexscreener")}
        # Cross-check GeckoTerminal untuk pool yang sama (bukan venue baru).
        if (ingested.get("geckoterminal_pool_address") or "").lower() == addr:
            g = ingested.get("geckoterminal_pool") or {}
            gattr = g.get("attributes", {}) if isinstance(g, dict) else {}
            gprice = _to_float(gattr.get("base_token_price_usd"))
            gres = _to_float(gattr.get("reserve_in_usd"))
            obs["cross_check"] = {
                "price_usd": gprice, "reserve_usd": gres,
                "fetched_at": ingested["meta"]["fetched_at"],
                "source": ingested["meta"]["sources"].get("geckoterminal"),
                "note": "same_pool_not_independent_venue"}
        pools.append(obs)
    pools.sort(key=lambda o: o["liquidity_usd"], reverse=True)

    # ---- underlying proxy (dex baseline "xyz"). Label eksplisit.
    proxy = None
    hl = ingested["hyperliquid"]
    instr = tok["proxy_instrument"]
    if instr in hl:
        raw = hl[instr]
        funding = _to_float(raw.get("funding"))
        oi = _to_float(raw.get("openInterest"))
        mark = _to_float(raw.get("markPx"))
        orac = _to_float(raw.get("oraclePx"))
        oi_notional = None
        if oi is not None and mark is not None:
            oi_notional = oi * mark  # DERIVED, beri label (bukan raw)
        proxy = {"instrument": instr, "dex": tok["proxy_dex"],
                 "funding_raw": funding, "funding_unit": "fraction/1h",
                 "funding_interval": "1h",
                 "open_interest_raw": oi, "oi_unit": "base_asset_units",
                 "oi_notional_usd_derived": oi_notional,
                 "markPx": mark, "oraclePx": orac,
                 "observed_at": ingested["meta"]["fetched_at"],
                 "source": ingested["meta"]["sources"].get("hyperliquid"),
                 "label": "UNDERLYING EQUITY PERP PROXY",
                 # OI change 24h: butuh baseline. Belum ada -> null.
                 "oi_change_24h": None,
                 "oi_change_24h_basis": "insufficient_history_no_baseline"}
    else:
        missing.append("underlying_proxy:" + instr)

    coverage = {
        "independent_pool_count": len({o["pool_address"].lower() for o in pools}),
        "independent_venue_count": len({o["dex"] for o in pools}),
        "missing_fields": missing,
        "rejected_observations": rejected,
    }

    snap = {
        "schema_version": config.SCHEMA_VERSION,
        "methodology_version": config.METHODOLOGY_VERSION,
        "fetched_at": ingested["meta"]["fetched_at"],
        "asset": asset,
        "reference": reference,
        "multiplier": multiplier,
        "pools": pools,
        "coverage": coverage,
        # exit_quote: TIDAK ADA quoter adapter di prototipe ini.
        # Status: indicative_only / exit_quality_unverified (§6B).
        "exit_quote": None,
        "underlying_proxy": proxy,
        "assessment": None,
        "proposal": None,
        "alert": None,
        "_token_ok": token_ok,
        "_fetch_errors": ingested["meta"]["errors"],
    }
    snap["snapshot_id"] = "snap-" + _short_hash(_canonical(
        {k: v for k, v in snap.items() if not k.startswith("_")}))
    return snap


# ------------------------------------------------------------------ assess
def assess_snapshot(snap):
    """Penilaian tiga lapis (§6). Reason codes + coverage. BUKAN angka 0-100.

    Lapisan A: kondisi DEX token (median dari observasi independen).
    Lapisan B: bukti exit (tanpa sell quote -> indicative_only).
    Lapisan C: konteks underlying (proxy terpisah, tidak memicu alert token).
    """
    # token_ok: field internal `_token_ok` hanya ada di snapshot internal.
    # Snapshot publik (replay) tidak membawanya — turunkan ulang dari
    # identitas aset + tidak ada penolakan contract_address/symbol.
    token_ok = snap.get("_token_ok")
    if token_ok is None:
        tok = config.TOKENS.get(snap.get("asset", {}).get("symbol", ""))
        addr_ok = bool(tok) and (
            (snap.get("asset", {}).get("token_address", "") or "").lower()
            == tok["token_address"].lower())
        rej = (snap.get("coverage") or {}).get("rejected_observations") or []
        id_rej = any(
            isinstance(r, dict) and r.get("field") in ("contract_address", "symbol")
            for r in rej)
        token_ok = bool(addr_ok and not id_rej)
    codes = []
    layer_a = {"median_price_usd": None, "per_venue_deviation_pct": {},
               "nav_gap_pct_labeled": None, "note": ""}
    layer_b = {"exit_quote": None,
               "status": "indicative_only/exit_quality_unverified",
               "note": "no_sell_quote_adapter_in_prototype"}
    layer_c = {"proxy": None, "note": ""}

    pools = snap["pools"]
    n_pool = snap["coverage"]["independent_pool_count"]
    n_venue = snap["coverage"]["independent_venue_count"]

    # ---- Lapisan A: median + deviasi per-venue (hanya observasi independen)
    if n_pool < config.MIN_INDEPENDENT_POOLS:
        codes.append("insufficient_cross_venue_coverage")
        layer_a["note"] = (
            "only_%d_independent_pool(s)_%d_venue(s)_below_min_%d_no_deviation_computed"
            % (n_pool, n_venue, config.MIN_INDEPENDENT_POOLS))
    else:
        prices = sorted(o["indicative_price_usd"] for o in pools)
        m = len(prices)
        median = prices[m // 2] if m % 2 == 1 else (prices[m // 2 - 1] + prices[m // 2]) / 2.0
        layer_a["median_price_usd"] = median
        for o in pools:
            dev = (o["indicative_price_usd"] - median) / median * 100.0
            layer_a["per_venue_deviation_pct"][o["pool_address"]] = round(dev, 4)
        if m == 2:
            codes.append("median_fragile_two_observations")
            layer_a["note"] = "median_from_only_2_observations_fragile"
        # Gap DEX-vs-NAV beku: DESKRIPSI BERLABEL saja (§3). Bukan
        # diskon/mispricing/arbitrase/tidak-bisa-dieksploitasi/pasti-false-positive.
        nav = snap["reference"]["nav_price"]
        if nav is not None and nav > 0:
            gap = (median - nav) / nav * 100.0
            layer_a["nav_gap_pct_labeled"] = {
                "value_pct": round(gap, 4),
                "label": "dex_median_vs_last_published_nav",
                "nav_age_seconds": snap["reference"]["age_seconds"],
                "session_status": snap["reference"]["session_status"],
                "note": "labeled_description_only_cause_and_exploitability_unproven",
            }
        # Deviasi ekstrem / watch (threshold eksperimen, belum tervalidasi).
        max_dev = max((abs(v) for v in layer_a["per_venue_deviation_pct"].values()),
                      default=0.0)
        if max_dev > config.DEV_ABSTAIN_PCT:
            codes.append("dex_deviation_extreme")
        elif max_dev > config.DEV_WATCH_PCT:
            codes.append("dex_deviation_watch")

    # ---- Lapisan B: bukti exit
    if snap["exit_quote"] is None:
        codes.append("no_exit_quote_adapter")
        # TVL/likuiditas BUKAN bukti exit. Tidak dipakai di sini (§3, §6B).

    # ---- Lapisan C: konteks underlying (proxy terpisah)
    proxy = snap["underlying_proxy"]
    if proxy is None:
        codes.append("proxy_missing")
        layer_c["note"] = "underlying_proxy_not_found_in_hyperliquid_response"
    else:
        layer_c["proxy"] = {
            "instrument": proxy["instrument"], "dex": proxy["dex"],
            "funding_raw": proxy["funding_raw"],
            "funding_unit": proxy["funding_unit"],
            "open_interest_raw": proxy["open_interest_raw"],
            "oi_unit": proxy["oi_unit"],
            "oi_change_24h": None,
            "label": proxy["label"],
        }
        layer_c["note"] = (
            "proxy_displayed_separately_does_not_trigger_token_exit_alert")

    # ---- status + NAV basi (informasional; off_hours by-design, bukan blocker)
    if not token_ok:
        codes.append("token_not_confirmed")
    if snap["reference"]["nav_price"] is None:
        codes.append("reference_invalid")
    nav_age = snap["reference"]["age_seconds"]
    if nav_age is not None and nav_age > config.NAV_STALE_HOURS * 3600:
        codes.append("nav_stale_off_hours")

    blocking = {"token_not_confirmed", "reference_invalid",
                "insufficient_cross_venue_coverage", "dex_deviation_extreme"}
    if any(c in blocking for c in codes):
        status = "degraded"
    elif codes:
        status = "degraded"
    else:
        status = "ok"
    # "degraded" bila ada reason code apa pun (termasuk no_exit_quote).
    # Ini jujur: prototipe ini belum punya bukti exit, jadi tidak pernah "ok"
    # penuh selama quoter belum ada. Status "ok" hanya bila semua bersih.
    if not token_ok or snap["reference"]["nav_price"] is None:
        status = "unknown"

    basis = ("pools=%d venues=%d nav_age=%s session=%s exit_quote=%s proxy=%s"
             % (n_pool, n_venue,
                ("%.1fh" % (nav_age / 3600.0)) if nav_age is not None else "unknown",
                snap["reference"]["session_status"],
                "present" if snap["exit_quote"] else "absent",
                "present" if proxy else "absent"))
    snap["assessment"] = {"status": status, "reason_codes": codes,
                          "confidence_basis": basis,
                          "layer_a": layer_a, "layer_b": layer_b,
                          "layer_c": layer_c}
    return snap


# ------------------------------------------------------------------ decide
def decide(snap):
    """Policy deterministik (POLICY_VERSION). ABSTAIN / WATCH / PAPER_PROPOSAL.

    Aturan (berurutan):
    1. Blocking (token tak terkonfirmasi / referensi invalid / coverage tak
       cukup / deviasi ekstrem) -> ABSTAIN.
    2. Tanpa sell quote -> maks WATCH (tanpa bukti exit, usulan beli dilarang).
    3. Ada reason watch -> WATCH.
    4. Selain itu (butuh quote + semua bersih) -> PAPER_PROPOSAL.
    Di prototipe ini (tanpa quoter), PAPER_PROPOSAL tidak terjangkau — itu
    jujur dan by-design, bukan bug. Menahan semua alokasi di cash simulasi
    adalah hasil yang sah.
    """
    codes = set(snap["assessment"]["reason_codes"])
    blocking = {"token_not_confirmed", "reference_invalid",
                "insufficient_cross_venue_coverage", "dex_deviation_extreme"}
    reasons = []
    if codes & blocking:
        decision = "ABSTAIN"
        reasons = sorted(codes & blocking)
    elif "no_exit_quote_adapter" in codes:
        decision = "WATCH"
        reasons = ["no_exit_quote_adapter"] + sorted(
            c for c in codes if c != "no_exit_quote_adapter")
    elif codes:
        decision = "WATCH"
        reasons = sorted(codes)
    else:
        decision = "PAPER_PROPOSAL"
        reasons = []

    # Proposal: bobot/nominal adalah parameter policy EKSPERIMEN, bukan
    # preferensi investasi Alex. Jangan isi toleransi risiko Alex diam-diam.
    if decision == "PAPER_PROPOSAL":
        # Hanya terjangkau bila ada exit quote (saat ini tidak ada).
        w = min(config.MAX_WEIGHT_PER_ASSET,
                1.0 / max(len(snap["pools"]), 1))
        proposal = {"weights": {snap["asset"]["symbol"]: round(w, 4)},
                    "cash_weight": round(1.0 - w, 4),
                    "simulation_notional": config.SIMULATION_NOTIONAL_USD,
                    "horizon_days": config.HORIZON_DAYS,
                    "expiry_days": config.EXPIRY_DAYS,
                    "reason": "exit_evidence_present_and_conditions_benign"}
    else:
        proposal = {"weights": {},
                    "cash_weight": 1.0,
                    "simulation_notional": config.SIMULATION_NOTIONAL_USD,
                    "horizon_days": config.HORIZON_DAYS,
                    "expiry_days": config.EXPIRY_DAYS,
                    "reason": "holding_all_simulated_cash_" + decision.lower()}
    snap["proposal"] = proposal
    snap["decision"] = decision
    snap["decision_reasons"] = reasons
    snap["policy_version"] = config.POLICY_VERSION
    return snap


# ------------------------------------------------------------------ explain
def explain(snap):
    """Rangkuman alasan + sumber dari objek tervalidasi. Jangan menciptakan
    harga/quote/alasan finansial baru."""
    a = snap["assessment"]
    ref = snap["reference"]
    lines = []
    lines.append("Decision %s under %s for %s (chain %s, contract %s)."
                 % (snap["decision"], snap["policy_version"],
                    snap["asset"]["symbol"], snap["asset"]["chain"],
                    snap["asset"]["token_address"]))
    lines.append("Reason codes: %s." % (", ".join(snap["decision_reasons"])
                                        or "none"))
    nav = ref["nav_price"]
    if nav is not None:
        lines.append("Reference NAV (already multiplier-adjusted, NOT "
                     "multiplied again): %s, updated %s, age %s, session %s."
                     % (nav, ref["nav_price_updated_at"],
                        ("%d seconds" % ref["age_seconds"])
                        if ref["age_seconds"] is not None else "unknown",
                        ref["session_status"]))
    else:
        lines.append("Reference NAV: unknown (not confirmed).")
    la = a["layer_a"]
    if la["median_price_usd"] is not None:
        lines.append("DEX median (independent pools=%d, venues=%d): %s USD."
                     % (snap["coverage"]["independent_pool_count"],
                        snap["coverage"]["independent_venue_count"],
                        la["median_price_usd"]))
        if la["nav_gap_pct_labeled"] is not None:
            g = la["nav_gap_pct_labeled"]
            lines.append("Labeled description: DEX median is %s%% vs last "
                         "published NAV (age %s seconds, session %s). "
                         "Cause and exploitability unproven; not labeled a "
                         "discount, mispricing, or arbitrage."
                         % (g["value_pct"], g["nav_age_seconds"],
                            g["session_status"]))
    else:
        lines.append("DEX median: not computed (%s)."
                     % (la["note"] or "insufficient coverage"))
    lines.append("Exit evidence: %s (no sell quote adapter in this prototype; "
                 "liquidity/TVL is not used as exit evidence)."
                 % a["layer_b"]["status"])
    if snap["underlying_proxy"] is not None:
        p = snap["underlying_proxy"]
        lines.append("Underlying context (UNDERLYING EQUITY PERP PROXY, "
                     "separate): %s funding %s %s, OI raw %s %s. Proxy does "
                     "not trigger a token-exit alert."
                     % (p["instrument"], p["funding_raw"], p["funding_unit"],
                        p["open_interest_raw"], p["oi_unit"]))
    else:
        lines.append("Underlying proxy: unknown (not found).")
    if snap["decision"] in ("ABSTAIN", "WATCH"):
        lines.append("Paper record: all simulated cash (cash_weight 1.0), "
                     "no buy proposed. Holding cash is a valid outcome.")
    snap["explanation"] = " ".join(lines)
    return snap


# ------------------------------------------------------------------- alert
def alert_id_for(snap, mode):
    """ID alert deterministik: hash(snapshot_id + rule_version + decision +
    reason codes + asset + mode). Input sama -> ID sama (idempotensi)."""
    canon = _canonical({
        "snapshot_id": snap["snapshot_id"],
        "rule_version": snap["policy_version"],
        "decision": snap["decision"],
        "reasons": sorted(snap["decision_reasons"]),
        "asset": snap["asset"]["symbol"],
        "mode": mode,
    })
    return "alert-" + _short_hash(canon)


def emit_alert(snap, mode, seen_path):
    """Serialisasi payload alert ke dict (ditulis file oleh run.py).

    Dedup: bila alert_id sudah ada di seen_path, kembalikan duplicate=True
    dan JANGAN buat payload baru. Mode TEST/REPLAY dipakai saat replay agar
    alert sintetis tidak dikira kejadian pasar live.
    """
    aid = alert_id_for(snap, mode)
    seen = {}
    try:
        with open(seen_path, "r", encoding="utf-8") as f:
            seen = json.load(f)
    except (OSError, ValueError):
        seen = {}
    if aid in seen:
        return {"duplicate": True, "alert_id": aid,
                "mode": mode, "seen_before": seen[aid]}
    payload = {
        "alert_id": aid,
        "mode": mode,
        "rule_version": snap["policy_version"],
        "snapshot_id": snap["snapshot_id"],
        "asset": snap["asset"]["symbol"],
        "decision": snap["decision"],
        "reasons": sorted(snap["decision_reasons"]),
        "assessment_status": snap["assessment"]["status"],
        "median_price_usd": snap["assessment"]["layer_a"]["median_price_usd"],
        "nav_gap_pct_labeled":
            snap["assessment"]["layer_a"]["nav_gap_pct_labeled"],
        "exit_evidence": snap["assessment"]["layer_b"]["status"],
        "proxy_label": ("UNDERLYING EQUITY PERP PROXY"
                        if snap["underlying_proxy"] else None),
        "emitted_at": _iso(_now()),
        "note": ("TEST/REPLAY alert from a controlled replay, not a live "
                 "market event." if mode == "TEST/REPLAY" else
                 "Local alert only. Not sent to any production channel."),
    }
    seen[aid] = {"emitted_at": payload["emitted_at"], "mode": mode,
                 "snapshot_id": snap["snapshot_id"]}
    try:
        with open(seen_path, "w", encoding="utf-8") as f:
            json.dump(seen, f, indent=2, sort_keys=True)
    except OSError:
        pass
    return {"duplicate": False, "alert_id": aid, "mode": mode,
            "payload": payload}


# -------------------------------------------------------------- paper record
def paper_record(snap):
    """Simpan usulan + snapshot yang mendasarinya. Tidak ada transaksi.
    Tidak ada klaim fill/return bila hanya ada indicative price."""
    return {
        "snapshot_id": snap["snapshot_id"],
        "asset": snap["asset"]["symbol"],
        "decision": snap["decision"],
        "decision_reasons": snap["decision_reasons"],
        "proposal": snap["proposal"],
        "assessment": snap["assessment"],
        "explanation": snap["explanation"],
        "fetched_at": snap["fetched_at"],
        "policy_version": snap["policy_version"],
        "methodology_version": snap["methodology_version"],
        "note": ("Paper (simulated) decision only. No transaction, no fill, "
                 "no return claim. Indicative prices only."),
    }


# ------------------------------------------------------------------- driver
def run_token(symbol, ingested=None):
    """Satu alur end-to-end untuk satu token (ingest->...->paper record)."""
    snap = build_snapshot(symbol, ingested=ingested)
    snap = assess_snapshot(snap)
    snap = decide(snap)
    snap = explain(snap)
    return snap


def public_snapshot(snap):
    """Snapshot tanpa field internal (prefix `_`) untuk disimpan/dibagikan."""
    return {k: v for k, v in snap.items() if not k.startswith("_")}
