# Decision memo — Prototipe kecil Base Stocks Maxxing

Tanggal: 22 November 2026 (WITA). Status: **gate 15/15 (9 lama + 6 baru
pasca-audit)**, prototipe lokal/offline selesai dan terverifikasi chief.
Memo ini untuk keputusan ACC Alex (Septian) atas fase berikutnya. **Lolos
gate bukan izin otomatis melanjutkan.**

## Update 22 Nov 21:20+ WITA — audit final Instinct + must-fix selesai

Audit final Instinct (skor kejujuran **8/10**, naik dari 7 setelah source
masuk): gate 9/9 di-re-run sendiri hasilnya **IDENTIK**; keempat koreksi
§3 terbukti ada di kode; live run jujur (WATCH semua, full cash).
**TAPI** ditemukan 4 must-fix yang lolos dari gate lama — semuanya sudah
diperbaiki chief + regression tests ditambahkan (gate kini **15/15**):
- **A. Quote kosong meloloskan proposal.** Guard exit-evidence hanya cek
  `exit_quote is None` — quote `{}` menghasilkan PAPER_PROPOSAL 9%.
  Fix: validator quote eksplisit (`verified`/`invalid`/`missing`/`stale`,
  cek chain/token/side/jumlah/output/notional/waktu/expiry/jenis quote) +
  feature gate `PAPER_PROPOSALS_ENABLED = False` (proposal TIDAK PERNAH
  keluar selama gate mati, apa pun isi quote). Invariant: PAPER_PROPOSAL
  selalu mensyaratkan layer B verified.
- **B. Freshness pool/quote belum diimplementasi.** `MAX_POOL_AGE_MIN` ada
  di config tapi tidak dipakai. Fix: freshness per-jenis-data (pool dari
  `fetched_at` + timestamp harga sumber; quote dari `quoted_at`/`expires_at`;
  NAV dari timestamp vs jam evaluasi + sesi pasar NYSE minimal), reason
  codes terpisah, `eval_at` injectable, replay berlabel replay.
- **C. Replay percaya chain + coverage turunan.** Chain tidak divalidasi,
  count tersimpan dipercaya. Fix: validasi chain+contract+symbol+decimals;
  coverage dihitung ulang dari pool tervalidasi (dedup case-insensitive,
  venue dikanonisasi: `aero` == `aerodrome`, min 2 venue kanonis);
  identitas snapshot divalidasi via hash payload awal (diubah -> ditandai
  `snapshot_transformed_replay`).
- **D. Dedup gagal diam-diam.** Error baca/tulis ditelan, emit dilaporkan
  sukses. Fix: error eksplisit terstruktur (`ok` + `error{stage,type,
  message}`), bedakan first-run vs corrupt vs permission; tulis atomik
  (temp + os.replace) + file lock (dua worker bersamaan -> tepat satu emit
  baru). Pemanggil WAJIB cek `ok` (run.py sudah diperbarui).
- **Tambahan §3:** happy-path parametrik NVDAc+AAPLc via adapter mock dari
  raw capture; test NAV/multiplier pada build; output gate memuat run time,
  identitas source (sha256), dan test config; evidence capture
  (`capture_evidence.py`) + manifest hash; raw GeckoTerminal AAPLc sudah
  ada. **Quoter TETAP belum dipasang; PAPER_PROPOSAL tetap tidak terjangkau
  (gate mati) — sesuai batas keras audit.**

## Ringkasan satu kalimat

Plumbing alert end-to-end terbukti jalan (9/9), tapi prototipe ini masih
**monitor indikatif** — belum ada bukti exit (sell quote) — sehingga
pembeda produk ("bisa keluar, dengan bukti harga seperti apa?") **belum
terbukti**.

## Apa yang lulus

- **Gate: 15/15 PASS** (9 lama + 6 baru pasca-audit; terverifikasi chief
  dengan `python3 gate.py`, 22 Nov ~21:30 WITA). Happy path 10/10, NAV
  weekend 8/8, multiplier 4/4, liquidity vs exit 5/5, quote validation
  22/22, freshness 13/13, coverage recomputed 11/11, dedup persistence
  10/10, happy-path kedua token 16/16, NAV/multiplier build 8/8. Hasil di
  `out/gate_log.md` + `out/gate_results.json` (memuat run time, sha256
  source, dan test config).
- **Ingest live berfungsi.** NVDAc + AAPLc teridentifikasi via Coinbase API
  (tanpa key); pool nyata terkonfirmasi (Aerodrome Slipstream); proxy
  underlying `xyz:NVDA` / `xyz:AAPL` ditemukan di Hyperliquid
  (`metaAndAssetCtxs`). Respons mentah tersimpan di `evidence/`.
- **Keputusan jujur.** Live run: NVDAc → WATCH, AAPLc → WATCH. Keduanya
  menahan seluruh alokasi simulasi di cash (`cash_weight: 1.0`,
  `weights: {}`) karena tidak ada bukti exit. Tidak ada usulan beli palsu.
- **Koreksi Instinct §3 diterapkan dan terbukti:** NAV tidak dikali multiplier
  lagi (tes multiplier 4/4); dua agregator baca pool sama = satu pool
  (tes coverage); gap DEX-vs-NAV hanya deskripsi berlabel (bukan mispricing);
  TVL tidak dipakai sebagai bukti exit (tes liquidity vs exit); proxy
  dilabeli terpisah dan tidak memicu alert token-exit (tes proxy).
- **Replay + idempotensi berfungsi.** Snapshot publik dapat di-replay
  (`run.py --replay`), alert tidak terduplikasi, alert replay berlabel
  `TEST/REPLAY`. Bug replay (`KeyError: '_token_ok'`) ditemukan saat
  verifikasi chief dan sudah diperbaiki (lihat `DESIGN.md` §9).
- **Batas fase dipegang.** Tidak ada onchain, tidak ada deploy, tidak ada
  ubah Radar live, tidak ada kirim alert ke Telegram produksi, tidak ada
  pendaftaran kompetisi. Semua lokal/offline.

## Apa yang gagal / terbatas (jujur)

- **Tidak ada sell-quote adapter → tidak ada bukti exit.** Ini keterbatasan
  terbesar dan struktural, bukan bug. Status exit selalu
  `indicative_only/exit_quality_unverified`. Prototipe ini memonitor kondisi
  indikatif; **tidak cukup untuk mengklaim exit-quality atau mengizinkan
  usulan beli berbasis bukti exit.** (Sesuai §7 brief: ketiadaan executable
  quote tidak menggagalkan demonstrasi plumbing, tapi membatasi hasil menjadi
  monitor indikatif.)
- **Registry pause tidak dibaca.** `registry_pause_status: unknown`
  (butuh RPC read-only; di luar scope adapter HTTP). Bila registry ternyata
  pause, prototipe tidak akan tahu.
- **Coverage lintas-venue tipis.** Efektif 1 pool dominan per token
  (Aerodrome). Median dari 2 observasi rapuh. Belum ada sensus venue lengkap.
- **Threshold belum tervalidasi.** DEV_WATCH 2% / DEV_ABSTAIN 5% adalah
  tebakan awal versioned — tidak ada data false-positive / false-negative.
  Kalibrasi butuh seri historis + definisi outcome.
- **Tidak ada bukti kualitas prediktif.** Lolos test teknis bukan bukti
  kualitas prediktif atau keuntungan. Tidak ada backtest, tidak ada outcome.
- **PoR + redemption tetap `unknown`.** Tidak ada sumber otomatis. Ini
  batas jujur, bukan kegagalan — tapi artinya skor "exit-ability setara
  Solana" tidak bisa dibangun dari prototipe ini.

## Apa yang masih unknown

- Apakah sell-quote adapter feasible untuk token ini (quoter Aerodrome
  Slipstream / API quoter lain)? Belum diteliti. Ini penentu apakah
  pembeda produk bisa dibuktikan.
- Apakah registry pause bisa dibaca via RPC publik Base (read-only)?
  Belum dicoba.
- Apakah ada venue/pool lain yang material di luar Aerodrome? Belum disensus.
- Apakah rubrik kompetisi menghargai paper-portfolio / testnet? Masih
  terbuka (bukan diselesaikan gate teknis ini).
- Apakah bobot traction 50/25/25 adalah rules resmi? Tidak terverifikasi —
  jangan diasumsikan.

## Estimasi sisa pekerjaan (berdasarkan source yang benar-benar diperiksa)

| Pekerjaan | Estimasi | Keterangan |
|---|---|---|
| Riset + bangun sell-quote adapter (read-only) | 0,5–1 hari | Tentukan quoter (Aerodrome Slipstream / API). Bila quoter tidak ada / tidak bisa dipakai read-only → blocker, STOP untuk klaim exit-quality. |
| Baca registry pause via RPC publik Base | 1–2 jam | Butuh endpoint RPC publik read-only. |
| Sensus venue/pool tambahan | 2–3 jam | Cek DEX lain di Base untuk NVDAc/AAPLc. |
| Kalibrasi threshold (historis) | Di luar jendela | Butuh seri historis + definisi outcome; tidak bisa selesai sebelum 28 Nov secara kredibel. Threshold tetap eksperimen. |
| Desain hash registry Base Sepolia (§8) | Sudah ada di `DESIGN.md` §8 | Spesifikasi saja; deploy menunggu gate + ACC. |
| QA + submission (bila lanjut) | 1–3 Des QA, 4 Des submit (buffer) | Hanya sesudah gate + ACC eksplisit. Deadline resmi 5 Des 23:59 UTC = 6 Des 07:59 WITA. |

## Pilihan: GO terbatas atau STOP

**Opsi A — GO TERBATAS (rekomendasi chief).**
Lanjutkan **hanya** ke satu langkah berikutnya yang terdefinisi: riset +
bangun sell-quote adapter + baca registry pause, lalu jalankan ulang gate.
Batas waktu: selesai sebelum review 28 Nov. **Stop condition keras:** bila
quoter terbukti tidak feasible (tidak ada quoter read-only yang bisa
dipakai), berhenti — jangan klaim exit-quality dari monitor indikatif.
Bila quoter jalan, prototipe menjadi monitor bukti-exit yang jujur, dan
keputusan lanjut ke QA/submission dibahas lagi dengan ACC eksplisit.

Alasan: plumbing sudah terbukti (9/9). Quoter adalah satu-satunya blocker
untuk pembeda produk. Langkahnya kecil dan terdefinisi. Risiko terbatas
(kill-switch 30 Nov tetap berlaku).

**Opsi B — STOP.**
Berhenti di sini. Prototipe disimpan sebagai bukti teknis (plumbing +
gate) tanpa dilanjutkan ke kompetisi. Alasan yang sah: sisa waktu
(8 hari ke kill-switch 30 Nov) tidak cukup untuk quoter + kalibrasi +
onchain + QA + submission secara kredibel; atau Septian menilai monitor
indikatif saja tidak cukup kuat sebagai entry kompetisi.

**Yang tidak direkomendasikan:** lanjut ke build penuh / submission dengan
menganggap monitor indikatif ini sudah membuktikan exit-quality. Itu
overclaim — bertentangan dengan brief Instinct §7 dan dengan kejujuran
produk ("bisa keluar, dengan bukti harga seperti apa?").

## Keputusan yang diminta dari Alex

Pilih **Opsi A (GO terbatas, ke quoter + registry)** atau **Opsi B (STOP)**.
Bila Opsi A, chief lanjut ke riset quoter. Bila Opsi B, prototipe diarsipkan
dan tidak ada pekerjaan Base lebih lanjut sebelum keputusan baru.
