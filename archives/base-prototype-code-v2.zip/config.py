"""Konfigurasi prototipe Base Stocks Maxxing (lokal/offline).

Sumber otoritatif: brief Instinct (brief-instinct-muse.md).
Semua endpoint publik, read-only, TANPA API key. Tidak ada secret/kunci/token.

KOREKSI YANG MENGIKAT (brief Instinct §3):
- nav_price SUDAH multiplier-adjusted / total-return. JANGAN dikali multiplier lagi.
  Rumus harga token = harga equity x multiplier hanya untuk harga saham MENTAH.
- Gap DEX-vs-NAV beku = deskripsi berlabel saja. Bukan diskon/mispricing/arbitrase.
- TVL/reserve/likuiditas pool BUKAN executable depth. Hanya filter kelayakan.
- Redemption: desain mengasumsikan TIDAK ADA jalur permissionless retail.
- PoR: tidak ada sumber otomatis. Hanya catatan manual atau `unknown`.
- Dua agregator yang membaca pool sama = SATU pool, bukan dua venue independen.
- Hyperliquid: perp TOKEN (NVDAc/AAPLc) tidak ada. Yang ada adalah perp
  UNDERLYING di dex lain: `xyz:NVDA` / `xyz:AAPL` (baseline) dan `io:NVDA` /
  `io:AAPL`. Funding/OI itu UNDERLYING EQUITY PERP PROXY, bukan ukuran
  exit-risk token Base. Jangan agregasi xyz: dan io: tanpa metodologi eksplisit.
"""

# ---------------------------------------------------------------- identitas
# Kunci identitas: chain + contract, BUKAN ticker saja (brief §3).
# Nilai ini adalah kunci lookup (fakta identitas), bukan data pasar.
# Data pasar (nav_price, multiplier, harga) TIDAK di-hard-code; diambil live.
CHAIN = "base"

TOKENS = {
    "NVDAc": {
        "chain": CHAIN,
        "token_address": "0xb20000000000000000000078ee7ce2fE4908108C",
        "symbol": "NVDAc",
        "name": "NVIDIA Corporation",
        "decimals": 8,
        # Pool Aerodrome Slipstream NVDAc/USDC (teramati saat validasi).
        # Dipakai HANYA sebagai cross-check ekspektasi, bukan sumber kebenaran.
        # Adapter menemukan pool dari DexScreener; bila pool ini tidak muncul,
        # itu temuan (bukan asumsi).
        "expected_pool": "0xF668e21993f0ACd7ab00BB1cFbAeD0df28A3C8EC",
        # Proxy underlying (baseline): instrumen Hyperliquid di dex "xyz".
        "proxy_instrument": "xyz:NVDA",
        "proxy_dex": "xyz",
    },
    "AAPLc": {
        "chain": CHAIN,
        "token_address": "0xb200000000000000000000C2e324d24d7eEcd1fb",
        "symbol": "AAPLc",
        "name": "Apple Inc.",
        "decimals": 8,
        "expected_pool": "0xF5FCB9CDAFcE67d50AfEf298F88E709d2B946BA6",
        "proxy_instrument": "xyz:AAPL",
        "proxy_dex": "xyz",
    },
}

# ---------------------------------------------------------------- sumber data
# Semua publik, read-only, tanpa key. Tidak ada pendaftaran/akun.
COINBASE_API_URL = "https://api.coinbase.com/v1/tokenized-stocks"
COINBASE_DOCS_URL = "https://docs.base.org/sdks/tokenized-stocks/overview"
COINBASE_B20_DOCS_URL = "https://docs.base.org/build-on-base/integrate-defi/list-tokenized-stocks"
DEXSCREENER_URL = "https://api.dexscreener.com/latest/dex/tokens/{address}"
GECKOTERMINAL_POOL_URL = "https://api.geckoterminal.com/api/v2/networks/base/pools/{pool}"
HYPERLIQUID_INFO_URL = "https://api.hyperliquid.xyz/info"
# Dex baseline untuk proxy underlying. Varian "io:" ada tapi TIDAK diagregasi
# (brief §5: hindari agregasi xyz: dan io: tanpa metodologi eksplisit).
PROXY_BASELINE_DEX = "xyz"
ORACLE_REGISTRY = "0x3f3E8cf41cdd3b1D118c16471aB0113DfDDd5CaD"
# Registry pause TIDAK dibaca di prototipe ini (butuh RPC read-only; di luar
# scope adapter HTTP). Nilainya `unknown` (brief §5). Dicatat sebagai gap.

# ---------------------------------------------------------------- versi
SCHEMA_VERSION = "base-proto-schema v0.2.0"
METHODOLOGY_VERSION = "base-proto-method v0.2.0"
POLICY_VERSION = "base-proto-policy v0.2.0"
# Semua versi di atas adalah EKSPERIMEN, belum tervalidasi (brief §6).
# v0.2.0 (22 Nov 2026, pasca-audit Instinct): validator quote eksplisit +
# feature gate proposal, freshness per-jenis-data, coverage dihitung ulang
# dari pool tervalidasi, dedup persist eksplisit. Lihat DECISION_MEMO.md.

# ---------------------------------------------------------------- policy
# Threshold eksperimen (versioned, jelas berlabel BELUM TERVALIDASI).
# Bukan kalibrasi; bukan warisan Solana (bobot / min-3-dari-5 / threshold 70
# Solana TIDAK dipakai di sini). Tradeoff FP/FN ada di DESIGN.md.
# - DEV_WATCH_PCT rendah (2%)  -> lebih sering WATCH (FP "watch" lebih tinggi).
# - DEV_ABSTAIN_PCT tinggi (5%) -> ABSTAIN hanya pada deviasi ekstrem.
# - REQUIRE_EXIT_QUOTE_FOR_PROPOSAL: tanpa sell quote, keputusan maks WATCH.
#   (Tanpa bukti exit, usulan beli tidak boleh keluar.)
DEV_WATCH_PCT = 2.0          # |deviasi vs median| > 2%  -> WATCH
DEV_ABSTAIN_PCT = 5.0        # |deviasi vs median| > 5%  -> ABSTAIN
MIN_INDEPENDENT_POOLS = 2    # butuh >=2 pool independen utk confidence lintas-venue
MIN_INDEPENDENT_VENUES = 2   # butuh >=2 venue kanonis (bukan hanya 2 pool)
NAV_STALE_HOURS = 24         # umur NAV > 24 jam = referensi basi (informasional)
MAX_FUTURE_SKEW_SEC = 300    # toleransi jam sumber maju (clock skew) 5 menit
MAX_POOL_AGE_MIN = 60        # observasi pool lebih tua dari ini = basi (informasional)
QUOTE_MAX_AGE_SEC = 300      # umur quote > 5 menit = stale (tidak bisa jadi bukti exit)
# Feature gate proposal (audit A, 22 Nov 2026): PAPER_PROPOSAL TIDAK PERNAH
# keluar selama gate ini False — apa pun isi exit_quote (null, kosong,
# valid sekalipun). Gate hanya dinyalakan eksplisit SETELAH quoter terpasang
# dan direview ulang. Jangan mengandalkan kebiasaan adapter mengisi None.
PAPER_PROPOSALS_ENABLED = False
# Pemetaan alias venue -> nama kanonis (audit C). Dua label untuk venue yang
# sama TIDAK dihitung sebagai dua venue independen. Hanya alias yang
# tercantum di sini yang dipetakan; label lain dipakai apa adanya (lowercase).
VENUE_ALIASES = {
    "aero": "aerodrome",
    "aerodrome": "aerodrome",
    "aerodrome slipstream": "aerodrome",
    "uniswap v2": "uniswap",
    "uniswap v3": "uniswap",
    "uniswap": "uniswap",
}
# Kalender pasar minimal (audit B): sesi AS (NYSE) untuk membedakan NAV basi
# saat market aktif vs market tutup. Daftar libur NYSE 2026 (tetap; wajib
# diperbarui tiap tahun — tanpa ini, sesi libur dibaca `unknown`, bukan tutup).
# Jam market 09:30-16:00 US/Eastern, Senin-Jumat. Early close tidak dimodelkan.
US_MARKET_HOLIDAYS_2026 = {
    "2026-01-01",  # New Year's Day
    "2026-01-19",  # Martin Luther King Jr. Day
    "2026-02-16",  # Presidents' Day
    "2026-04-03",  # Good Friday
    "2026-05-25",  # Memorial Day
    "2026-06-19",  # Juneteenth
    "2026-07-03",  # Independence Day (observed; 4 Jul = Sabtu)
    "2026-09-07",  # Labor Day
    "2026-11-26",  # Thanksgiving
    "2026-12-25",  # Christmas Day
}
# Parameter paper portfolio (EKSPERIMEN, bukan preferensi investasi Alex).
SIMULATION_NOTIONAL_USD = 10_000.0
MAX_WEIGHT_PER_ASSET = 0.50
HORIZON_DAYS = 7
EXPIRY_DAYS = 7

# ---------------------------------------------------------------- batas
HTTP_TIMEOUT_SEC = 30
USER_AGENT = "base-prototype/0.1.0 (read-only, no key; research prototype)"
