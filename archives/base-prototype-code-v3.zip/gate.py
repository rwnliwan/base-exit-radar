"""Gerbang alert end-to-end (§7 brief Instinct) — 9 tes.

Setiap tes memakai snapshot nyata (fixtures/snapshot_live_20261122_*.json)
atau fixture yang dimodifikasi dari snapshot itu (disimpan di fixtures/).
Replay memakai mode TEST/REPLAY agar alert sintetis tidak dikira kejadian
pasar live. Alert dedup memakai seen file SEMENTARA (bukan alerts_seen.json
produksi lokal) agar tes tidak mencemari dedup run live.

Penggunaan:
  python3 gate.py
Output:
  out/gate_results.json   (hasil per tes: expected vs actual, pass/fail)
  out/gate_log.md         (log test yang bisa dibaca manusia)

Kriteria lulus per tes ada di docstring masing-masing tes (dari §7 brief).
"""

import copy
import hashlib
import json
import os
import sys
import tempfile
from datetime import timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
import pipeline

BASE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(BASE, "fixtures")
OUT = os.path.join(BASE, "out")
SEEN_TEST = os.path.join(OUT, "alerts_seen_gate_test.json")


def _load_fixture(name):
    with open(os.path.join(FIX, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _save_fixture(name, obj):
    p = os.path.join(FIX, name)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")
    return p


def _reassess(snap, eval_at=None, eval_context="replay"):
    """Jalankan ulang assess+decide+explain dari snapshot (tanpa fetch).
    Default eval_context="replay" (gate menilai ulang snapshot historis);
    eval_at default = fetched_at snapshot (evaluasi "sewaktu" diambil)."""
    snap = pipeline.assess_snapshot(snap, eval_at=eval_at,
                                    eval_context=eval_context)
    snap = pipeline.decide(snap)
    snap = pipeline.explain(snap)
    return snap


def _recompute_snapshot_id(snap):
    """Hitung ulang snapshot_id dari payload awal (setelah memodifikasi
    snapshot untuk tes). Dipakai agar snapshot sintetis yang dibangun tes
    punya identitas konsisten (bukan ditandai transformed)."""
    payload = pipeline._build_time_payload(snap)
    snap["snapshot_id"] = "snap-" + pipeline._short_hash(
        pipeline._canonical(payload))
    return snap


def _fresh_nav_fixture(symbol="NVDAc"):
    """Fixture live dengan NAV fresh (age 1 detik, session active) — kontrol
    untuk tes quote/freshness, seperti repro audit."""
    base = _load_fixture("snapshot_live_20261122_%s.json" % symbol)
    snap = copy.deepcopy(base)
    fetched = pipeline._parse_ts(snap["fetched_at"])
    snap["reference"].update(
        age_seconds=1,
        nav_price_updated_at=pipeline._iso(
            fetched - timedelta(seconds=1)),
        session_status="active",
        session_status_basis="controlled_fresh_nav_fixture",
    )
    return snap


def _valid_quote(symbol, eval_at, notional_usd=10000.0):
    """Quote jual firm yang valid untuk tes (kind=firm, SELL, token_out alamat
    USDC Base asli, notional cukup, quoted 60 dtk sebelum eval, expiry 600
    dtk sesudah eval). Implied price 10400/80 = 130.0 vs median fixture
    131.97 (rasio 0.985, dalam toleransi sanity ±10%); notional hitung
    80 x 131.97 = 10557.6 >= proposal 10000; notional dinyatakan 10000
    konsisten dengan hitung (rasio 0.947, dalam 2x)."""
    tok = config.TOKENS[symbol]
    quoted = eval_at - timedelta(seconds=60)
    expires = eval_at + timedelta(seconds=600)
    return {
        "chain": config.CHAIN,
        "token_in": tok["token_address"],
        "token_out": "0x833589fCD6eDb6E08f4c7C32D4f71b54bd029029",
        "side": "SELL",
        "amount_in": 80.0,
        "amount_out_min": 10400.0,
        "quoted_at": pipeline._iso(quoted),
        "expires_at": pipeline._iso(expires),
        "source": "test-quoter",
        "venue": "aerodrome",
        "kind": "firm",
        "notional_usd": notional_usd,
    }


# ------------------------------------------------------------------ tes A
def test_quote_validation():
    """Audit A: validator quote eksplisit. Null/kosong/malformed/invalid/
    stale TIDAK BOLEH menghasilkan proposal (cash-only). PAPER_PROPOSAL
    selalu mensyaratkan layer B verified + feature gate nyala."""
    base = _fresh_nav_fixture("NVDAc")
    eval_at = pipeline._parse_ts(base["fetched_at"])
    cases = []  # (nama, quote, kode_yang_diharapkan)
    cases.append(("null", None, "exit_quote_missing"))
    cases.append(("empty_dict", {}, "exit_quote_empty"))
    cases.append(("string", "not-a-quote", "exit_quote_malformed"))
    cases.append(("list", [], "exit_quote_malformed"))
    q = _valid_quote("NVDAc", eval_at)
    q2 = copy.deepcopy(q)
    del q2["amount_out_min"]
    cases.append(("missing_field", q2, "exit_quote_missing_fields"))
    q = _valid_quote("NVDAc", eval_at)
    q["chain"] = "ethereum"
    cases.append(("wrong_chain", q, "exit_quote_wrong_chain"))
    q = _valid_quote("NVDAc", eval_at)
    q["token_in"] = "0x0000000000000000000000000000000000000000"
    cases.append(("wrong_token", q, "exit_quote_wrong_token"))
    q = _valid_quote("NVDAc", eval_at)
    q["side"] = "BUY"
    cases.append(("wrong_side", q, "exit_quote_wrong_side"))
    q = _valid_quote("NVDAc", eval_at)
    q["amount_in"] = 0
    cases.append(("amount_zero", q, "exit_quote_bad_amount"))
    q = _valid_quote("NVDAc", eval_at)
    q["amount_in"] = float("nan")
    cases.append(("amount_nan", q, "exit_quote_bad_amount"))
    q = _valid_quote("NVDAc", eval_at)
    q["amount_out_min"] = -5
    cases.append(("output_negative", q, "exit_quote_bad_output"))
    q = _valid_quote("NVDAc", eval_at)
    q["kind"] = "indicative"
    cases.append(("indicative", q, "exit_quote_indicative_only"))
    q = _valid_quote("NVDAc", eval_at)
    q["kind"] = "simulation"
    cases.append(("simulation", q, "exit_quote_simulation_only"))
    q = _valid_quote("NVDAc", eval_at)
    q["quoted_at"] = pipeline._iso(
        eval_at - timedelta(seconds=3600))
    cases.append(("stale_quote", q, "exit_quote_stale"))
    q = _valid_quote("NVDAc", eval_at)
    q["quoted_at"] = pipeline._iso(
        eval_at + timedelta(seconds=3600))
    cases.append(("future_quote", q, "exit_quote_future_timestamp"))
    q = _valid_quote("NVDAc", eval_at)
    q["expires_at"] = pipeline._iso(
        eval_at - timedelta(seconds=10))
    cases.append(("expired_quote", q, "exit_quote_expired"))
    q = _valid_quote("NVDAc", eval_at)
    q["error"] = "quoter_unavailable"
    cases.append(("source_error", q, "exit_quote_source_error"))
    q = _valid_quote("NVDAc", eval_at, notional_usd=100.0)
    cases.append(("small_notional", q, "exit_quote_notional_insufficient"))
    q = _valid_quote("NVDAc", eval_at)
    del q["notional_usd"]
    cases.append(("notional_unknown", q, "exit_quote_notional_unknown"))
    # --- Re-audit v2, E1: validator terlalu longgar (ketiga probe ini lolos
    # sebagai verified di v0.2.0). Wajib ditolak sebelum gate dinyalakan.
    q = _valid_quote("NVDAc", eval_at)
    del q["kind"]
    cases.append(("kind_missing", q, "exit_quote_kind_missing"))
    q = _valid_quote("NVDAc", eval_at)
    q["token_out"] = "SCAMCOIN"
    cases.append(("token_out_scamcoin", q, "exit_quote_token_out_not_usdc"))
    q = _valid_quote("NVDAc", eval_at)
    q["amount_out_min"] = 1.0
    q["notional_usd"] = 1e12
    cases.append(("absurd_output_and_notional", q, "exit_quote_price_sanity_fail"))
    # Isolasi: harga ngawur dengan notional konsisten -> sanity harga.
    q = _valid_quote("NVDAc", eval_at)
    q["amount_out_min"] = 1.0
    q["notional_usd"] = 10557.6
    cases.append(("absurd_output_only", q, "exit_quote_price_sanity_fail"))
    # Isolasi: notional ngawur dengan harga wajar -> mismatch.
    q = _valid_quote("NVDAc", eval_at)
    q["notional_usd"] = 1e12
    cases.append(("absurd_notional_only", q, "exit_quote_notional_mismatch"))

    failed = []
    for name, quote, want_code in cases:
        snap = copy.deepcopy(base)
        snap["exit_quote"] = quote
        snap = _reassess(snap, eval_at=eval_at)
        ok = (snap["decision"] != "PAPER_PROPOSAL"
              and snap["proposal"]["cash_weight"] == 1.0
              and want_code in snap["assessment"]["reason_codes"]
              and snap["assessment"]["layer_b"]["status"]
              != "verified")
        if not ok:
            failed.append("%s: decision=%s codes=%s" % (
                name, snap["decision"], snap["assessment"]["reason_codes"]))
    # Kontrol null-vs-empty dari lampiran audit: sama-sama cash-only.
    # Invariant: PAPER_PROPOSAL butuh layer B verified + gate nyala.
    # (a) Quote valid + gate NYALA (sementara) -> PAPER_PROPOSAL, layer B verified.
    snap = copy.deepcopy(base)
    snap["exit_quote"] = _valid_quote("NVDAc", eval_at)
    _recompute_snapshot_id(snap)
    old_gate = config.PAPER_PROPOSALS_ENABLED
    try:
        config.PAPER_PROPOSALS_ENABLED = True
        snap = _reassess(snap, eval_at=eval_at)
        inv_a = (snap["decision"] == "PAPER_PROPOSAL"
                 and snap["assessment"]["layer_b"]["status"] == "verified"
                 and snap["proposal"]["weights"].get("NVDAc", 0) > 0)
    finally:
        config.PAPER_PROPOSALS_ENABLED = old_gate
    if not inv_a:
        failed.append("invariant_valid_quote_gate_on: decision=%s layer_b=%s"
                      % (snap["decision"],
                         snap["assessment"]["layer_b"]["status"]))
    # (b) Quote valid + gate MATI (default) -> WATCH paper_proposals_disabled.
    snap = copy.deepcopy(base)
    snap["exit_quote"] = _valid_quote("NVDAc", eval_at)
    _recompute_snapshot_id(snap)
    snap = _reassess(snap, eval_at=eval_at)
    if not (snap["decision"] == "WATCH"
            and "paper_proposals_disabled" in snap["decision_reasons"]):
        failed.append("invariant_valid_quote_gate_off: decision=%s reasons=%s"
                      % (snap["decision"], snap["decision_reasons"]))
    # (c) Quote invalid (kosong) + gate NYALA -> tetap WATCH (bukan proposal).
    snap = copy.deepcopy(base)
    snap["exit_quote"] = {}
    _recompute_snapshot_id(snap)
    try:
        config.PAPER_PROPOSALS_ENABLED = True
        snap = _reassess(snap, eval_at=eval_at)
        inv_c = snap["decision"] != "PAPER_PROPOSAL"
    finally:
        config.PAPER_PROPOSALS_ENABLED = old_gate
    if not inv_c:
        failed.append("invariant_empty_quote_gate_on: decision=%s"
                      % snap["decision"])
    return _result(
        "quote_validation",
        "null/empty/malformed/invalid/stale quotes -> cash-only WATCH; "
        "PAPER_PROPOSAL requires verified layer B + gate on",
        "%d/%d cases cash-only; failed: %s"
        % (len(cases) + 3 - len(failed), len(cases) + 3, failed or "none"),
        not failed,
        "validator statuses: missing/invalid/stale; gate default OFF")


# ------------------------------------------------------------------ tes B
def test_freshness():
    """Audit B: freshness per-jenis-data (pool/quote/NAV) benar-benar diuji,
    bukan hanya string status. Reason codes terpisah; batas threshold tepat;
    replay historis vs evaluasi live dibedakan."""
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    eval_at = pipeline._parse_ts(base["fetched_at"])
    checks = []

    # (a) DEX stale: semua pool fetched_at + source_updated_at -> 2026-01-01.
    s = copy.deepcopy(base)
    for p in s["pools"]:
        p["fetched_at"] = "2026-01-01T00:00:00Z"
        p["source_updated_at"] = "2026-01-01T00:00:00Z"
    s = _reassess(s, eval_at=eval_at)
    checks.append(("dex_stale_code",
                   "dex_pool_stale" in s["assessment"]["reason_codes"]))
    checks.append(("dex_stale_no_proposal",
                   s["decision"] != "PAPER_PROPOSAL"))
    # (b) Source timestamp unknown -> kode informasional terpisah.
    s = copy.deepcopy(base)
    s = _reassess(s, eval_at=eval_at)
    checks.append(("price_ts_unknown_code",
                   "dex_price_timestamp_unknown"
                   in s["assessment"]["reason_codes"]))
    # (c) Fetch baru + harga sumber tua -> pool basi (fetch != harga fresh).
    s = copy.deepcopy(base)
    for p in s["pools"]:
        p["source_updated_at"] = "2026-01-01T00:00:00Z"
    s = _reassess(s, eval_at=eval_at)
    checks.append(("fresh_fetch_old_price_stale",
                   "dex_pool_stale" in s["assessment"]["reason_codes"]))
    # (d) Quote stale terpisah dari NAV stale (NAV fresh, quote basi).
    s = _fresh_nav_fixture("NVDAc")
    q = _valid_quote("NVDAc", eval_at)
    q["quoted_at"] = pipeline._iso(
        eval_at - timedelta(seconds=3600))
    s["exit_quote"] = q
    s = _reassess(s, eval_at=eval_at)
    checks.append(("quote_stale_separate",
                   "exit_quote_stale" in s["assessment"]["reason_codes"]
                   and "nav_stale_off_hours"
                   not in s["assessment"]["reason_codes"]))
    # (e) NAV stale saat market AKTIF (Senin 23 Nov 2026 15:00 UTC = 10:00 ET).
    s = copy.deepcopy(base)
    monday_open = pipeline._parse_ts("2026-11-23T15:00:00Z")
    s = _reassess(s, eval_at=monday_open)
    checks.append(("nav_stale_active_session",
                   "nav_stale_active_session"
                   in s["assessment"]["reason_codes"]))
    # (f) NAV stale saat market TUTUP (Minggu) -> tanpa active_session.
    s = copy.deepcopy(base)
    sunday = pipeline._parse_ts("2026-11-22T15:00:00Z")
    s = _reassess(s, eval_at=sunday)
    checks.append(("nav_stale_weekend_no_active",
                   "nav_stale_off_hours" in s["assessment"]["reason_codes"]
                   and "nav_stale_active_session"
                   not in s["assessment"]["reason_codes"]))
    # (g) NAV stale saat libur (Thanksgiving 26 Nov 2026) -> tanpa active.
    s = copy.deepcopy(base)
    thanksgiving = pipeline._parse_ts("2026-11-26T15:00:00Z")
    s = _reassess(s, eval_at=thanksgiving)
    checks.append(("nav_stale_holiday_no_active",
                   "nav_stale_off_hours" in s["assessment"]["reason_codes"]
                   and "nav_stale_active_session"
                   not in s["assessment"]["reason_codes"]))
    # (h) Timestamp NAV hilang -> reason eksplisit, bukan diam-diam WATCH.
    s = copy.deepcopy(base)
    s["reference"].update(nav_price_updated_at=None, age_seconds=None,
                          session_status="unknown")
    s = _reassess(s, eval_at=eval_at)
    checks.append(("nav_timestamp_unknown_code",
                   "nav_timestamp_unknown"
                   in s["assessment"]["reason_codes"]))
    # (i) Batas tepat threshold pool: umur tepat 60 menit -> fresh; 60m+1d -> basi.
    s = copy.deepcopy(base)
    for p in s["pools"]:
        p["fetched_at"] = pipeline._iso(
            eval_at - timedelta(minutes=60))
    s = _reassess(s, eval_at=eval_at)
    checks.append(("pool_age_exact_60m_fresh",
                   "dex_pool_stale" not in s["assessment"]["reason_codes"]))
    s = copy.deepcopy(base)
    for p in s["pools"]:
        p["fetched_at"] = pipeline._iso(
            eval_at - timedelta(minutes=60, seconds=1))
    s = _reassess(s, eval_at=eval_at)
    checks.append(("pool_age_60m1s_stale",
                   "dex_pool_stale" in s["assessment"]["reason_codes"]))
    # (j) Replay historis vs evaluasi live: snapshot yang sama, eval_at =
    # fetched_at (replay) -> pool fresh; eval_at = sekarang (live, jauh
    # setelah fetch) -> pool basi. Konteks evaluasi tercatat.
    s = copy.deepcopy(base)
    s_replay = _reassess(copy.deepcopy(s), eval_at=eval_at,
                         eval_context="replay")
    s_live = _reassess(copy.deepcopy(s), eval_at=pipeline._now(),
                       eval_context="live")
    checks.append(("replay_vs_live_freshness",
                   "dex_pool_stale" not in s_replay["assessment"]["reason_codes"]
                   and "dex_pool_stale" in s_live["assessment"]["reason_codes"]))
    checks.append(("eval_context_recorded",
                   s_replay["assessment"]["freshness"]["eval_context"] == "replay"
                   and s_live["assessment"]["freshness"]["eval_context"] == "live"))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "freshness",
        "DEX/quote/NAV freshness tested by time input; separate codes; "
        "replay vs live distinguished",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "pool/quote/nav stale codes + market session (open/closed/holiday)")


# ------------------------------------------------------------------ tes C
def test_coverage_recomputed():
    """Audit C: replay memvalidasi ulang chain + coverage dihitung ulang dari
    pool tervalidasi (bukan percaya count tersimpan). Alias venue dipetakan."""
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    eval_at = pipeline._parse_ts(base["fetched_at"])
    checks = []

    # (a) Wrong chain/contract/symbol/decimals -> token_not_confirmed + ABSTAIN.
    for field, value in (("chain", "ethereum"),
                         ("token_address",
                          "0x0000000000000000000000000000000000000000"),
                         ("symbol", "FAKEc"),
                         ("decimals", 6)):
        s = copy.deepcopy(base)
        s["asset"][field] = value
        s = _reassess(s, eval_at=eval_at)
        checks.append(("reject_%s" % field,
                       "token_not_confirmed" in s["assessment"]["reason_codes"]
                       and s["decision"] == "ABSTAIN"))
    # (b) Count palsu (terlalu tinggi/rendah) tidak mengubah hasil hitung ulang.
    # Hasil hitung ulang dibaca dari assessment.coverage_recomputed; count
    # tersimpan TIDAK dimutasi (re-audit v2, E2) — assess tidak menulis
    # ulang snap["coverage"].
    s = copy.deepcopy(base)
    s["coverage"]["independent_pool_count"] = 99
    s["coverage"]["independent_venue_count"] = 99
    s = _reassess(s, eval_at=eval_at)
    checks.append(("fake_count_high_ignored",
                   s["assessment"]["coverage_recomputed"]["recomputed_pool_count"] == 11
                   and s["assessment"]["coverage_recomputed"]["recomputed_venue_count"] == 6
                   and s["coverage"]["independent_pool_count"] == 99
                   and s["coverage"]["independent_venue_count"] == 99))
    s = copy.deepcopy(base)
    s["coverage"]["independent_pool_count"] = 0
    s["coverage"]["independent_venue_count"] = 0
    s = _reassess(s, eval_at=eval_at)
    checks.append(("fake_count_low_ignored",
                   s["assessment"]["coverage_recomputed"]["recomputed_pool_count"] == 11
                   and s["assessment"]["coverage_recomputed"]["recomputed_venue_count"] == 6
                   and s["coverage"]["independent_pool_count"] == 0
                   and s["coverage"]["independent_venue_count"] == 0))
    # (c) Duplikat address beda casing tidak menambah pool.
    s = copy.deepcopy(base)
    dup = copy.deepcopy(s["pools"][0])
    dup["pool_address"] = dup["pool_address"].upper()
    s["pools"].append(dup)
    s = _reassess(s, eval_at=eval_at)
    checks.append(("dup_address_case_insensitive",
                   s["assessment"]["coverage_recomputed"]["recomputed_pool_count"] == 11))
    # (d) Dua pool venue sama (aero + aerodrome = 1 venue) -> ABSTAIN.
    s = copy.deepcopy(base)
    s["pools"] = s["pools"][:2]
    for p in s["pools"]:
        p["dex"] = "aero"
    s["pools"][1]["dex"] = "aerodrome"
    s = _reassess(s, eval_at=eval_at)
    checks.append(("two_pools_one_venue_abstain",
                   s["decision"] == "ABSTAIN"
                   and "insufficient_cross_venue_coverage"
                   in s["assessment"]["reason_codes"]))
    # (e) Alias venue: aero + aerodrome dihitung 1 venue kanonis.
    s = copy.deepcopy(base)
    s = _reassess(s, eval_at=eval_at)
    checks.append(("venue_alias_canonical",
                   s["assessment"]["coverage_recomputed"]["recomputed_venue_count"] == 6
                   and "aerodrome" in s["assessment"]["coverage_recomputed"]["canonical_venues"]
                   and "aero" not in s["assessment"]["coverage_recomputed"]["canonical_venues"]))
    # (f) Payload diubah dengan ID/hash lama -> ditandai transformed replay.
    s = copy.deepcopy(base)
    s["pools"][0]["indicative_price_usd"] = 999.0
    s = _reassess(s, eval_at=eval_at)
    checks.append(("transformed_payload_marked",
                   "snapshot_transformed_replay"
                   in s["assessment"]["reason_codes"]))
    # (g) Payload asli (ID/hash cocok) -> tidak ditandai.
    s = copy.deepcopy(base)
    s = _reassess(s, eval_at=eval_at)
    checks.append(("original_payload_not_marked",
                   "snapshot_transformed_replay"
                   not in s["assessment"]["reason_codes"]))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "coverage_recomputed",
        "chain/identity validated; counts recomputed from validated pools; "
        "venue aliases canonical; transformed payloads marked",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "recomputed pools=11 venues=6 (aero==aerodrome)")


# ------------------------------------------- tes identitas snapshot (E2)
def test_snapshot_identity_live_build():
    """Re-audit v2, E2: snapshot yang dibangun build_snapshot HARUS
    self-consistent saat di-replay — identitas cocok, TIDAK ditandai
    transformed. Regresi atas bug v0.2.0: hash dihitung dari coverage mentah
    (7 venue, aero/aerodrome terpisah) tapi file menyimpan 6 (kanonis),
    sehingga snapshot live v0.2.0 ASLI ditandai transformed replay.
    Catatan: file live v0.2.0 lama (snap-a7da34c2855e4e92) tetap tidak konsisten
    secara konstruksi (hash atas 7, isi 6) — artefak historis, bukan target
    tes ini. Tes ini membuktikan snapshot yang dibangun kode BARU konsisten.
    """
    import adapter as _adapter
    evid = os.path.join(BASE, "evidence")

    def _load(name):
        with open(os.path.join(evid, name), "r", encoding="utf-8") as f:
            return json.load(f)

    cb = _load("coinbase_tokenized_stocks_page1.json")
    hl_xyz = _load("hyperliquid_metaAndAssetCtxs_xyz.json")

    def _hl_instruments(raw):
        meta, ctxs = raw[0], raw[1]
        out = {}
        for i, u in enumerate(meta.get("universe", [])):
            ctx = ctxs[i] if i < len(ctxs) else {}
            out[u.get("name")] = {
                "funding": ctx.get("funding"),
                "openInterest": ctx.get("openInterest"),
                "markPx": ctx.get("markPx"),
                "oraclePx": ctx.get("oraclePx"),
            }
        return out

    orig = (_adapter.fetch_coinbase_tokens,
            _adapter.fetch_dexscreener_pools,
            _adapter.fetch_geckoterminal_pool,
            _adapter.fetch_hyperliquid_proxy)
    checks = []
    try:
        for sym in ("NVDAc", "AAPLc"):
            ds = _load("dexscreener_%s.json" % sym.lower())
            gt = _load("geckoterminal_%s_pool.json" % sym.lower())
            _adapter.fetch_coinbase_tokens = lambda: {
                "ok": True, "tokens": cb.get("tokens", []),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.COINBASE_API_URL, "error": None, "pages": 1}
            _adapter.fetch_dexscreener_pools = lambda addr: {
                "ok": True, "pairs": ds.get("pairs", []),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.DEXSCREENER_URL.format(address=addr),
                "error": None}
            _adapter.fetch_geckoterminal_pool = lambda pool: {
                "ok": True, "pool": gt.get("data"),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.GECKOTERMINAL_POOL_URL.format(pool=pool),
                "error": None}
            _adapter.fetch_hyperliquid_proxy = lambda dex="xyz": {
                "ok": True, "instruments": _hl_instruments(hl_xyz),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.HYPERLIQUID_INFO_URL + " dex=" + dex,
                "error": None}
            # Bangun snapshot dengan kode BARU, nilai (assess), ambil bentuk
            # tersimpan (public_snapshot = isi file), lalu replay.
            snap = pipeline.build_snapshot(sym)
            snap = pipeline.assess_snapshot(snap)
            stored = pipeline.public_snapshot(snap)
            identity = pipeline.verify_snapshot_identity(stored)
            checks.append(("%s_build_identity_matches" % sym,
                           identity["matches"]))
            checks.append(("%s_build_coverage_canonical" % sym,
                           stored["coverage"]["independent_venue_count"]
                           == snap["assessment"]["coverage_recomputed"]["recomputed_venue_count"]
                           and stored["coverage"]["independent_pool_count"]
                           == snap["assessment"]["coverage_recomputed"]["recomputed_pool_count"]))
            replay = _reassess(copy.deepcopy(stored))
            checks.append(("%s_replay_not_transformed" % sym,
                           "snapshot_transformed_replay"
                           not in replay["assessment"]["reason_codes"]))
            checks.append(("%s_replay_coverage_agrees" % sym,
                           replay["assessment"]["coverage_recomputed"]["stored_venue_count"]
                           == replay["assessment"]["coverage_recomputed"]["recomputed_venue_count"]
                           and replay["assessment"]["coverage_recomputed"]["stored_pool_count"]
                           == replay["assessment"]["coverage_recomputed"]["recomputed_pool_count"]))
    finally:
        (_adapter.fetch_coinbase_tokens,
         _adapter.fetch_dexscreener_pools,
         _adapter.fetch_geckoterminal_pool,
         _adapter.fetch_hyperliquid_proxy) = orig
    failed = [c for c, ok in checks if not ok]
    return _result(
        "snapshot_identity_live_build",
        "snapshot built by fixed build_snapshot is self-consistent on replay: "
        "identity matches, no transformed flag, stored == recomputed coverage",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "E2 regression: build -> public_snapshot -> replay")


# ------------------------------------------------------------------ tes D
def test_dedup_persistence():
    """Audit D: kegagalan persist dedup eksplisit (bukan sukses palsu).
    Error terstruktur per field; replay setelah restart tetap duplicate;
    dua worker bersamaan tidak sama-sama dapat izin emit baru."""
    import subprocess
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    checks = []

    # (a) Parent dir tidak ada -> ok=False + error terstruktur, file tak ada.
    with tempfile.TemporaryDirectory() as d:
        bad = os.path.join(d, "missing-parent", "seen.json")
        r1 = pipeline.emit_alert(snap, "TEST/REPLAY", bad)
        r2 = pipeline.emit_alert(snap, "TEST/REPLAY", bad)
        checks.append(("missing_parent_error",
                       not r1["ok"] and not r2["ok"]
                       and r1["error"] is not None
                       and set(r1["error"]) >= {"stage", "type", "message"}
                       and not os.path.exists(bad)))
    # (b) Store corrupt -> ok=False, corrupt_store.
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "seen.json")
        with open(p, "w", encoding="utf-8") as f:
            f.write("{corrupt json")
        r = pipeline.emit_alert(snap, "TEST/REPLAY", p)
        checks.append(("corrupt_store_error",
                       not r["ok"]
                       and r["error"]["type"] == "corrupt_store"))
    # (c) Store JSON valid tapi bukan dict -> ok=False, malformed_store.
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "seen.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump([1, 2, 3], f)
        r = pipeline.emit_alert(snap, "TEST/REPLAY", p)
        checks.append(("malformed_store_error",
                       not r["ok"]
                       and r["error"]["type"] == "malformed_store"))
    # (d) Write gagal (parent adalah FILE, bukan dir) -> ok=False.
    with tempfile.TemporaryDirectory() as d:
        blocker = os.path.join(d, "blocker")
        with open(blocker, "w", encoding="utf-8") as f:
            f.write("x")
        p = os.path.join(blocker, "seen.json")
        r = pipeline.emit_alert(snap, "TEST/REPLAY", p)
        checks.append(("write_failure_error",
                       not r["ok"] and r["error"] is not None
                       and r["error"]["stage"] in ("lock", "write")))
    # (e) Disk penuh (simulasi via mock os.replace) -> ok=False.
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "seen.json")
        orig_replace = os.replace
        def _boom(*a, **k):
            raise OSError("No space left on device")
        os.replace = _boom
        try:
            r = pipeline.emit_alert(snap, "TEST/REPLAY", p)
        finally:
            os.replace = orig_replace
        checks.append(("disk_full_error",
                       not r["ok"] and r["error"]["stage"] == "write"))
    # (f) Replay setelah restart (proses baru) tetap duplicate.
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "seen.json")
        r1 = pipeline.emit_alert(snap, "TEST/REPLAY", p)
        code = (
            "import sys, json; sys.path.insert(0, %r); "
            "import pipeline; snap = pipeline.explain(pipeline.decide("
            "pipeline.assess_snapshot(json.load(open(%r))))); "
            "r = pipeline.emit_alert(snap, 'TEST/REPLAY', %r); "
            "print(json.dumps({'ok': r['ok'], 'duplicate': r['duplicate']}))"
            % (BASE, os.path.join(FIX, "snapshot_live_20261122_NVDAc.json"), p))
        out = subprocess.run([sys.executable, "-c", code],
                             capture_output=True, text=True, timeout=60)
        r2 = json.loads(out.stdout.strip().splitlines()[-1])
        checks.append(("restart_still_duplicate",
                       r1["ok"] and not r1["duplicate"]
                       and r2["ok"] and r2["duplicate"]))
    # (g) Dua worker bersamaan -> tepat satu dapat izin emit baru.
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "seen.json")
        code = (
            "import sys, json; sys.path.insert(0, %r); "
            "import pipeline; snap = pipeline.explain(pipeline.decide("
            "pipeline.assess_snapshot(json.load(open(%r))))); "
            "r = pipeline.emit_alert(snap, 'TEST/REPLAY', %r); "
            "print(json.dumps({'ok': r['ok'], 'duplicate': r['duplicate']}))"
            % (BASE, os.path.join(FIX, "snapshot_live_20261122_NVDAc.json"), p))
        procs = [subprocess.Popen([sys.executable, "-c", code],
                                  stdout=subprocess.PIPE, text=True)
                 for _ in range(2)]
        results = []
        for pr in procs:
            out, _ = pr.communicate(timeout=60)
            results.append(json.loads(out.strip().splitlines()[-1]))
        n_new = sum(1 for r in results if r["ok"] and not r["duplicate"])
        n_dup = sum(1 for r in results if r["ok"] and r["duplicate"])
        checks.append(("concurrent_one_new_one_dup",
                       n_new == 1 and n_dup == 1))
    # (h) Input malformed -> error terstruktur, diuji per field.
    v = pipeline.validate_snapshot_shape({})
    checks.append(("malformed_shape_fields",
                   not v["ok"]
                   and {e["field"] for e in v["errors"]}
                   >= {"snapshot_id", "asset", "reference", "pools",
                       "coverage", "fetched_at"}
                   and all(set(e) == {"field", "reason"} for e in v["errors"])))
    v = pipeline.validate_snapshot_shape("not-a-dict")
    checks.append(("malformed_shape_not_dict",
                   not v["ok"]
                   and v["errors"] == [{"field": "snapshot",
                                        "reason": "not_a_dict"}]))
    v = pipeline.validate_snapshot_shape(snap)
    checks.append(("valid_shape_ok", v["ok"] and v["errors"] == []))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "dedup_persistence",
        "persist failures are structured errors (not empty success); "
        "restart still duplicate; concurrent workers get exactly one new emit",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "error stages: lock/read/write; ok flag enforced")


# ------------------------------------------------------- tes happy-path x2
def test_happy_path_both_tokens():
    """Audit §3: happy-path parametrik NVDAc + AAPLc melewati adapter mock
    (raw capture) -> build -> assess -> decide -> explain -> emit ->
    paper record. Bukan hanya reassess fixture."""
    import adapter as _adapter
    evid = os.path.join(BASE, "evidence")

    def _load(name):
        with open(os.path.join(evid, name), "r", encoding="utf-8") as f:
            return json.load(f)

    cb = _load("coinbase_tokenized_stocks_page1.json")
    hl_xyz = _load("hyperliquid_metaAndAssetCtxs_xyz.json")

    def _hl_instruments(raw):
        meta, ctxs = raw[0], raw[1]
        out = {}
        for i, u in enumerate(meta.get("universe", [])):
            ctx = ctxs[i] if i < len(ctxs) else {}
            out[u.get("name")] = {
                "funding": ctx.get("funding"),
                "openInterest": ctx.get("openInterest"),
                "markPx": ctx.get("markPx"),
                "oraclePx": ctx.get("oraclePx"),
            }
        return out

    orig = (_adapter.fetch_coinbase_tokens,
            _adapter.fetch_dexscreener_pools,
            _adapter.fetch_geckoterminal_pool,
            _adapter.fetch_hyperliquid_proxy)
    checks = []
    try:
        for sym in ("NVDAc", "AAPLc"):
            tok = config.TOKENS[sym]
            ds = _load("dexscreener_%s.json" % sym.lower())
            gt = _load("geckoterminal_%s_pool.json" % sym.lower())
            top = None
            cands = [p for p in ds.get("pairs", [])
                     if p.get("pairAddress", "").startswith("0x")]
            if cands:
                def _liq(p):
                    try:
                        return float((p.get("liquidity") or {}).get("usd") or -1)
                    except (TypeError, ValueError):
                        return -1.0
                top = max(cands, key=_liq).get("pairAddress")
            _adapter.fetch_coinbase_tokens = lambda: {
                "ok": True, "tokens": cb.get("tokens", []),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.COINBASE_API_URL, "error": None, "pages": 1}
            _adapter.fetch_dexscreener_pools = lambda addr: {
                "ok": True, "pairs": ds.get("pairs", []),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.DEXSCREENER_URL.format(address=addr),
                "error": None}
            _adapter.fetch_geckoterminal_pool = lambda pool: {
                "ok": True, "pool": gt.get("data"),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.GECKOTERMINAL_POOL_URL.format(pool=pool),
                "error": None}
            _adapter.fetch_hyperliquid_proxy = lambda dex="xyz": {
                "ok": True, "instruments": _hl_instruments(hl_xyz),
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.HYPERLIQUID_INFO_URL + " dex=" + dex,
                "error": None}
            snap = pipeline.run_token(sym)
            snap = pipeline.explain(snap)
            if os.path.exists(SEEN_TEST):
                os.remove(SEEN_TEST)
            res = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
            rec = pipeline.paper_record(snap)
            checks.append(("%s_decision_watch_or_abstain" % sym,
                           snap["decision"] in ("WATCH", "ABSTAIN")))
            checks.append(("%s_identity" % sym,
                           snap["asset"]["chain"] == "base"
                           and snap["asset"]["token_address"].lower()
                           == tok["token_address"].lower()))
            checks.append(("%s_nav_present" % sym,
                           snap["reference"]["nav_price"] is not None
                           and snap["reference"]["nav_price"] > 0))
            checks.append(("%s_pools" % sym,
                           snap["coverage"]["independent_pool_count"] >= 1))
            checks.append(("%s_explain" % sym,
                           isinstance(snap.get("explanation"), str)
                           and len(snap["explanation"]) > 50))
            checks.append(("%s_emit_ok" % sym,
                           res["ok"] and not res["duplicate"]))
            checks.append(("%s_paper_record" % sym,
                           rec["decision"] == snap["decision"]
                           and rec["proposal"]["cash_weight"] == 1.0))
            checks.append(("%s_top_pool_crosscheck" % sym,
                           top is not None
                           and snap["pools"][0]["pool_address"] == top))
    finally:
        (_adapter.fetch_coinbase_tokens,
         _adapter.fetch_dexscreener_pools,
         _adapter.fetch_geckoterminal_pool,
         _adapter.fetch_hyperliquid_proxy) = orig
    failed = [c for c, ok in checks if not ok]
    return _result(
        "happy_path_both_tokens",
        "NVDAc + AAPLc full chain (mock adapter from raw capture): build, "
        "assess, decide, explain, emit, paper record",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "raw capture evidence/ used as adapter mock source")


# ------------------------------------------------------- tes NAV x multiplier
def test_nav_multiplier_build():
    """Audit §3: test NAV memakai variasi NAV/multiplier PADA BUILD (bukan
    hanya konstanta fixture). NAV disimpan apa adanya, tidak dikali lagi."""
    import adapter as _adapter
    evid = os.path.join(BASE, "evidence")

    def _load(name):
        with open(os.path.join(evid, name), "r", encoding="utf-8") as f:
            return json.load(f)

    cb = _load("coinbase_tokenized_stocks_page1.json")
    ds = _load("dexscreener_nvdac.json")
    gt = _load("geckoterminal_nvdac_pool.json")
    hl_xyz = _load("hyperliquid_metaAndAssetCtxs_xyz.json")

    def _hl_instruments(raw):
        meta, ctxs = raw[0], raw[1]
        out = {}
        for i, u in enumerate(meta.get("universe", [])):
            ctx = ctxs[i] if i < len(ctxs) else {}
            out[u.get("name")] = {
                "funding": ctx.get("funding"),
                "openInterest": ctx.get("openInterest"),
                "markPx": ctx.get("markPx"),
                "oraclePx": ctx.get("oraclePx"),
            }
        return out

    orig = (_adapter.fetch_coinbase_tokens,
            _adapter.fetch_dexscreener_pools,
            _adapter.fetch_geckoterminal_pool,
            _adapter.fetch_hyperliquid_proxy)
    checks = []
    try:
        _adapter.fetch_dexscreener_pools = lambda addr: {
            "ok": True, "pairs": ds.get("pairs", []),
            "fetched_at": pipeline._iso(pipeline._now()),
            "source": config.DEXSCREENER_URL.format(address=addr),
            "error": None}
        _adapter.fetch_geckoterminal_pool = lambda pool: {
            "ok": True, "pool": gt.get("data"),
            "fetched_at": pipeline._iso(pipeline._now()),
            "source": config.GECKOTERMINAL_POOL_URL.format(pool=pool),
            "error": None}
        _adapter.fetch_hyperliquid_proxy = lambda dex="xyz": {
            "ok": True, "instruments": _hl_instruments(hl_xyz),
            "fetched_at": pipeline._iso(pipeline._now()),
            "source": config.HYPERLIQUID_INFO_URL + " dex=" + dex,
            "error": None}
        # Variasi NAV/multiplier pada BUILD (kasus audit: NAV 200, mult 3).
        for nav, mult in ((200.0, 3.0), (129.82480034, 1.0005379395763694),
                          (50.5, 1.5), (1000.0, 0.5)):
            tokens = copy.deepcopy(cb.get("tokens", []))
            rec = None
            for t in tokens:
                if (t.get("contract_address") or "").lower() == \
                        config.TOKENS["NVDAc"]["token_address"].lower():
                    rec = t
                    break
            rec["nav_price"] = nav
            rec["multiplier"] = mult
            rec["nav_price_updated_at"] = pipeline._iso(pipeline._now())
            _adapter.fetch_coinbase_tokens = lambda: {
                "ok": True, "tokens": tokens,
                "fetched_at": pipeline._iso(pipeline._now()),
                "source": config.COINBASE_API_URL, "error": None, "pages": 1}
            snap = pipeline.build_snapshot("NVDAc")
            checks.append(("nav_%.1f_mult_%.2f_stored_as_is" % (nav, mult),
                           snap["reference"]["nav_price"] == nav
                           and snap["multiplier"]["value"] == mult))
            checks.append(("nav_%.1f_not_multiplied" % nav,
                           abs(snap["reference"]["nav_price"] - nav * mult) > 0.01
                           if abs(nav * mult - nav) > 0.01 else True))
    finally:
        (_adapter.fetch_coinbase_tokens,
         _adapter.fetch_dexscreener_pools,
         _adapter.fetch_geckoterminal_pool,
         _adapter.fetch_hyperliquid_proxy) = orig
    failed = [c for c, ok in checks if not ok]
    return _result(
        "nav_multiplier_build",
        "NAV stored as-is (not multiplied) across NAV/multiplier variations "
        "on the build path",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "variations: (200,3), (129.82,1.0005), (50.5,1.5), (1000,0.5)")


def _result(name, expected, actual, passed, details=""):
    return {"test": name, "expected": expected, "actual": actual,
            "pass": bool(passed), "details": details}


# ------------------------------------------------------------------- tes 1
def test_happy_path():
    """Dua token resmi terbaca, identitas tepat, nilai/timestamp/source
    tersimpan. Keputusan policy bisa dijelaskan sampai ke input."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    checks = []
    checks.append(("chain==base", snap["asset"]["chain"] == "base"))
    checks.append(("contract==expected",
                   snap["asset"]["token_address"].lower()
                   == config.TOKENS["NVDAc"]["token_address"].lower()))
    checks.append(("symbol==NVDAc", snap["asset"]["symbol"] == "NVDAc"))
    checks.append(("nav_price>0",
                   snap["reference"]["nav_price"] is not None
                   and snap["reference"]["nav_price"] > 0))
    checks.append(("nav_updated_at present",
                   snap["reference"]["nav_price_updated_at"] is not None))
    checks.append(("fetched_at present", bool(snap["fetched_at"])))
    checks.append(("pools>=min",
                   snap["coverage"]["independent_pool_count"]
                   >= config.MIN_INDEPENDENT_POOLS))
    checks.append(("decision in {ABSTAIN,WATCH,PAPER_PROPOSAL}",
                   snap["decision"] in ("ABSTAIN", "WATCH", "PAPER_PROPOSAL")))
    checks.append(("explanation non-empty",
                   isinstance(snap.get("explanation"), str)
                   and len(snap["explanation"]) > 50))
    checks.append(("explanation mentions contract",
                   snap["asset"]["token_address"] in snap["explanation"]))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "happy_path",
        "identity correct, values/timestamps/sources saved, decision explainable",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "snapshot=%s decision=%s" % (snap["snapshot_id"], snap["decision"]))


# ------------------------------------------------------------------- tes 2
def test_controlled_trigger():
    """Ubah satu fixture kondisi DEX secara eksplisit. Seluruh pipeline
    menghasilkan satu alert lokal TEST/REPLAY. Jangan klaim trigger sintetis
    sebagai alert pasar nyata."""
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = copy.deepcopy(base)
    # Ubah SATU pool (teratas by liquidity) agar harganya +8% di atas median.
    # Itu melewati DEV_ABSTAIN_PCT (5%) -> ABSTAIN (dex_deviation_extreme).
    median = snap["assessment"]["layer_a"]["median_price_usd"]
    top = snap["pools"][0]
    old_price = top["indicative_price_usd"]
    top["indicative_price_usd"] = round(median * 1.08, 4)
    _save_fixture("fixture_trigger_deviation.json", snap)
    snap = _reassess(snap)
    # Emit alert TEST/REPLAY (seen file sementara).
    if os.path.exists(SEEN_TEST):
        os.remove(SEEN_TEST)
    res = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    expected = ("decision=ABSTAIN reason=dex_deviation_extreme, "
                "one TEST/REPLAY alert emitted")
    actual = ("decision=%s reasons=%s alert_duplicate=%s mode=%s"
              % (snap["decision"], snap["decision_reasons"],
                 res["duplicate"], res["mode"]))
    passed = (snap["decision"] == "ABSTAIN"
              and "dex_deviation_extreme" in snap["decision_reasons"]
              and not res["duplicate"] and res["mode"] == "TEST/REPLAY")
    return _result("controlled_trigger", expected, actual, passed,
                   "input change: pool %s price %.4f -> %.4f (+8%% vs median %.2f); "
                   "rule_version=%s; alert_id=%s"
                   % (top["pool_address"], old_price,
                      top["indicative_price_usd"], median,
                      snap["policy_version"], res["alert_id"]))


# ------------------------------------------------------------------- tes 3
def test_nav_weekend():
    """Replay nilai NAV Jumat dan snapshot Minggu. NAV tampil sebagai last
    published reference + age/off-hours, tidak dipakai sebagai live-price
    alarm atau dasar mispricing."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    ref = snap["reference"]
    gap = snap["assessment"]["layer_a"]["nav_gap_pct_labeled"]
    checks = []
    checks.append(("nav_updated_at is Friday",
                   ref["nav_price_updated_at"].startswith("2026-11-20")))
    checks.append(("fetched_at is Sunday",
                   snap["fetched_at"].startswith("2026-11-22")))
    checks.append(("session_status==off_hours",
                   ref["session_status"] == "off_hours"))
    checks.append(("nav age > 24h", (ref["age_seconds"] or 0) > 24 * 3600))
    checks.append(("nav_gap is labeled description",
                   gap is not None
                   and gap["label"] == "dex_median_vs_last_published_nav"
                   and "cause_and_exploitability_unproven" in gap["note"]))
    checks.append(("nav_gap not labeled mispricing/arbitrage",
                   "mispricing" not in json.dumps(gap).lower()
                   or "unproven" in json.dumps(gap).lower()))
    # NAV gap TIDAK memicu reason code alert sendiri.
    checks.append(("no nav_gap reason code",
                   not any("nav_gap" in c or "mispric" in c
                           for c in snap["decision_reasons"])))
    # NAV tidak dikali multiplier (lihat juga tes 4).
    checks.append(("nav_price is raw (not multiplied)",
                   abs(ref["nav_price"] - 129.82480034) < 1e-9))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "nav_weekend",
        "NAV shown as last published reference + age/off-hours; not a live alarm",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "nav_age_seconds=%s nav_gap_pct=%s"
        % (ref["age_seconds"],
           (gap or {}).get("value_pct")))


# ------------------------------------------------------------------- tes 4
def test_multiplier():
    """Buktikan NAV tidak dikalikan lagi. Raw share conversion memakai
    multiplier yang sesuai waktu/unit."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    ref = snap["reference"]
    mult = snap["multiplier"]["value"]
    raw_nav = 129.82480034  # nilai mentah dari API Coinbase (evidence)
    checks = []
    # (a) nav_price yang disimpan == nilai mentah API (tidak dikali).
    checks.append(("stored nav == raw API nav",
                   abs(ref["nav_price"] - raw_nav) < 1e-9))
    # (b) Bila dikali multiplier, hasilnya BERBEDA -> bukti tidak dikali.
    multiplied = raw_nav * mult
    checks.append(("nav x multiplier != stored nav (proves not multiplied)",
                   abs(multiplied - ref["nav_price"]) > 0.01))
    # (c) Round-trip raw share: raw_share = nav / multiplier; lalu
    #     raw_share x multiplier == nav (konsisten, memakai multiplier
    #     yang efektif saat itu, bukan multiplier hari ini untuk seluruh seri).
    raw_share = raw_nav / mult
    checks.append(("raw_share x multiplier == nav (round-trip)",
                   abs(raw_share * mult - raw_nav) < 1e-9))
    # (d) Multiplier tercatat terpisah (untuk referensi), bukan diterapkan
    #     ke nav_price.
    checks.append(("multiplier recorded separately",
                   mult is not None and mult > 1.0))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "multiplier",
        "NAV not multiplied again; raw share conversion uses effective multiplier",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "nav=%.8f multiplier=%.16f nav_x_mult=%.8f raw_share=%.8f"
        % (raw_nav, mult, multiplied, raw_share))


# ------------------------------------------------------------------- tes 5
def test_missing_stale():
    """Putuskan sumber atau buat data basi. Usulan baru diblokir/ABSTAIN
    sesuai policy; tidak ada risiko nol palsu. Freshness gate quote,
    observasi DEX, dan NAV terpisah."""
    # (a) Sumber DEX putus: pools kosong.
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    s1 = copy.deepcopy(base)
    s1["pools"] = []
    s1["coverage"]["independent_pool_count"] = 0
    s1["coverage"]["independent_venue_count"] = 0
    _save_fixture("fixture_missing_pools.json", s1)
    s1 = _reassess(s1)
    a_ok = (s1["decision"] == "ABSTAIN"
            and "insufficient_cross_venue_coverage" in s1["decision_reasons"]
            and s1["assessment"]["layer_a"]["median_price_usd"] is None)
    # (b) NAV sangat basi (7 hari).
    s2 = copy.deepcopy(base)
    s2["reference"]["nav_price_updated_at"] = "2026-11-15T23:42:40Z"
    s2["reference"]["age_seconds"] = 7 * 24 * 3600
    s2["reference"]["session_status"] = "off_hours"
    _save_fixture("fixture_stale_nav.json", s2)
    s2 = _reassess(s2)
    b_ok = ("nav_stale_off_hours" in s2["decision_reasons"]
            and s2["decision"] in ("ABSTAIN", "WATCH")
            and s2["decision"] != "PAPER_PROPOSAL")
    # (c) Freshness gate terpisah: quote / DEX / NAV masing-masing tercatat.
    c_ok = (s1["assessment"]["layer_b"]["status"]
            == "indicative_only/exit_quality_unverified")
    passed = a_ok and b_ok and c_ok
    return _result(
        "missing_stale",
        "missing source -> ABSTAIN (no zero-risk); stale NAV flagged; gates separate",
        "missing_pools: decision=%s (expect ABSTAIN) ok=%s; "
        "stale_nav: decision=%s codes=%s ok=%s; gates_separate ok=%s"
        % (s1["decision"], a_ok, s2["decision"], s2["decision_reasons"],
           b_ok, c_ok),
        passed,
        "missing pools median=None (not 0); stale NAV age=604800s flagged")


# ------------------------------------------------------------------- tes 6
def test_coverage():
    """Dua agregator untuk satu pool dihitung satu pool. Satu venue tidak
    menghasilkan cross-venue confidence palsu."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    # (a) Pool teratas punya cross_check GeckoTerminal (pool yang sama).
    top = snap["pools"][0]
    a_ok = ("cross_check" in top
            and top["cross_check"].get("note")
            == "same_pool_not_independent_venue")
    # Jumlah pool di pools[] == independent_pool_count (tidak double-count).
    a_ok = a_ok and (len(snap["pools"])
                     == snap["coverage"]["independent_pool_count"])
    # (b) Hanya satu pool valid -> ABSTAIN, median None (bukan nol).
    s2 = copy.deepcopy(snap)
    s2["pools"] = [copy.deepcopy(s2["pools"][0])]
    s2["coverage"]["independent_pool_count"] = 1
    s2["coverage"]["independent_venue_count"] = 1
    _save_fixture("fixture_single_pool.json", s2)
    s2 = _reassess(s2)
    b_ok = (s2["decision"] == "ABSTAIN"
            and "insufficient_cross_venue_coverage" in s2["decision_reasons"]
            and s2["assessment"]["layer_a"]["median_price_usd"] is None)
    return _result(
        "coverage",
        "two aggregators one pool = one pool; one venue -> no false confidence",
        "cross_check_same_pool ok=%s; single_pool decision=%s (expect ABSTAIN) "
        "median=None ok=%s" % (a_ok, s2["decision"], b_ok),
        bool(a_ok and b_ok),
        "live pools=%d venues=%d; single-pool fixture median=None"
        % (snap["coverage"]["independent_pool_count"],
           snap["coverage"]["independent_venue_count"]))


# ------------------------------------------------------------------- tes 7
def test_proxy():
    """Funding ekstrem atau perubahan OI saja tidak memicu klaim token-exit.
    Label proxy bertahan sampai payload alert/paper proposal. Histori belum
    cukup menghasilkan null, bukan perubahan 24h rekaan."""
    base = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = copy.deepcopy(base)
    # Funding ekstrem (5%/jam) + OI raksasa pada proxy.
    snap["underlying_proxy"]["funding_raw"] = 0.05
    snap["underlying_proxy"]["open_interest_raw"] = 999999999.0
    _save_fixture("fixture_proxy_extreme.json", snap)
    snap = _reassess(snap)
    if os.path.exists(SEEN_TEST):
        os.remove(SEEN_TEST)
    res = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    # Keputusan TIDAK berubah karena proxy saja (tetap WATCH; bukan ABSTAIN
    # karena proxy, bukan PAPER_PROPOSAL).
    a_ok = (snap["decision"] == "WATCH"
            and "no_exit_quote_adapter" in snap["decision_reasons"])
    # Label proxy bertahan sampai payload alert.
    b_ok = (not res["duplicate"]
            and res["payload"]["proxy_label"]
            == "UNDERLYING EQUITY PERP PROXY")
    # OI change 24h = null (insufficient_history), bukan 0% / rekaan.
    c_ok = (snap["underlying_proxy"]["oi_change_24h"] is None
            and snap["underlying_proxy"]["oi_change_24h_basis"]
            == "insufficient_history_no_baseline")
    return _result(
        "proxy",
        "extreme funding/OI alone does not trigger token-exit claim; label persists; OI change null",
        "decision=%s (expect WATCH) ok=%s; alert proxy_label ok=%s; "
        "oi_change_24h=None ok=%s" % (snap["decision"], a_ok, b_ok, c_ok),
        bool(a_ok and b_ok and c_ok),
        "funding set to 0.05 (5%%/h); decision unchanged by proxy alone")


# ------------------------------------------------------------------- tes 8
def test_liquidity_vs_exit():
    """TVL besar tanpa sell quote tetap exit_quality_unverified; tidak ada
    klaim bisa menjual nominal tertentu."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    top_liq = snap["pools"][0]["liquidity_usd"] if snap["pools"] else 0
    checks = []
    checks.append(("top pool liquidity is large (>$1M)",
                   top_liq > 1_000_000))
    checks.append(("exit_quote is None", snap["exit_quote"] is None))
    checks.append(("layer_b status indicative_only",
                   snap["assessment"]["layer_b"]["status"]
                   == "indicative_only/exit_quality_unverified"))
    checks.append(("decision is not PAPER_PROPOSAL",
                   snap["decision"] != "PAPER_PROPOSAL"))
    # Tidak ada klaim "bisa menjual nominal X" di explanation/paper record.
    rec = pipeline.paper_record(snap)
    blob = json.dumps(rec) + snap["explanation"]
    checks.append(("no sell-nominal claim in paper record/explanation",
                   "can sell" not in blob.lower()
                   and "bisa menjual" not in blob.lower()))
    failed = [c for c, ok in checks if not ok]
    return _result(
        "liquidity_vs_exit",
        "large TVL without sell quote stays exit_quality_unverified; no sell claim",
        "%d/%d checks pass; failed: %s" % (len(checks) - len(failed),
                                           len(checks), failed or "none"),
        not failed,
        "top_pool_liquidity_usd=%.2f decision=%s" % (top_liq, snap["decision"]))


# ------------------------------------------------------------------- tes 9
def test_idempotency():
    """Replay snapshot/rule sama tidak menduplikasi alert. Input buruk
    menghasilkan error terstruktur, bukan output sukses kosong."""
    snap = _load_fixture("snapshot_live_20261122_NVDAc.json")
    snap = _reassess(copy.deepcopy(snap))
    if os.path.exists(SEEN_TEST):
        os.remove(SEEN_TEST)
    r1 = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    r2 = pipeline.emit_alert(snap, "TEST/REPLAY", SEEN_TEST)
    a_ok = (not r1["duplicate"] and r2["duplicate"]
            and r1["alert_id"] == r2["alert_id"])
    # Input buruk -> error terstruktur (exception), bukan sukses kosong.
    try:
        pipeline.assess_snapshot({})
        b_ok = False
        b_detail = "assess_snapshot({}) returned success (BAD: empty success)"
    except (KeyError, TypeError, AttributeError) as e:
        b_ok = True
        b_detail = "assess_snapshot({}) raised %s (structured error, not empty success)" % type(e).__name__
    return _result(
        "idempotency",
        "same snapshot/rule replay does not duplicate alert; bad input errors",
        "first emit duplicate=%s, second emit duplicate=%s, same id=%s; "
        "bad input: %s" % (r1["duplicate"], r2["duplicate"],
                           r1["alert_id"] == r2["alert_id"], b_detail),
        bool(a_ok and b_ok),
        "alert_id=%s" % r1["alert_id"])


# -------------------------------------------------------------------- main
TESTS = [
    ("happy_path", test_happy_path),
    ("controlled_trigger", test_controlled_trigger),
    ("nav_weekend", test_nav_weekend),
    ("multiplier", test_multiplier),
    ("missing_stale", test_missing_stale),
    ("coverage", test_coverage),
    ("proxy", test_proxy),
    ("liquidity_vs_exit", test_liquidity_vs_exit),
    ("idempotency", test_idempotency),
    # Regression pasca-audit Instinct 22 Nov 2026 (must-fix A-D + §3).
    ("quote_validation", test_quote_validation),
    ("freshness", test_freshness),
    ("coverage_recomputed", test_coverage_recomputed),
    ("snapshot_identity_live_build", test_snapshot_identity_live_build),
    ("dedup_persistence", test_dedup_persistence),
    ("happy_path_both_tokens", test_happy_path_both_tokens),
    ("nav_multiplier_build", test_nav_multiplier_build),
]


def _source_identity():
    """Identitas source yang diaudit: sha256 tiap file Python + versi."""
    files = ["pipeline.py", "config.py", "adapter.py", "run.py", "gate.py",
             "capture_evidence.py"]
    out = {}
    for name in files:
        p = os.path.join(BASE, name)
        if os.path.exists(p):
            with open(p, "rb") as f:
                out[name] = hashlib.sha256(f.read()).hexdigest()
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    run_at = pipeline._iso(pipeline._now())
    results = []
    for name, fn in TESTS:
        try:
            r = fn()
        except Exception as e:  # noqa: BLE001 - satu tes gagal != crash harness
            r = _result(name, "see test docstring",
                        "EXCEPTION %s: %s" % (type(e).__name__, e), False,
                        "test raised; harness continued")
        results.append(r)
        mark = "PASS" if r["pass"] else "FAIL"
        print("[%s] %s: %s" % (mark, r["test"], r["actual"]))
    n_pass = sum(1 for r in results if r["pass"])
    summary = {"gate": "base-prototype §7 + audit regression A-D",
               "run_at": run_at,
               "policy_version": config.POLICY_VERSION,
               "methodology_version": config.METHODOLOGY_VERSION,
               "schema_version": config.SCHEMA_VERSION,
               "source_identity": _source_identity(),
               "test_config": {
                   "min_independent_pools": config.MIN_INDEPENDENT_POOLS,
                   "min_independent_venues": config.MIN_INDEPENDENT_VENUES,
                   "nav_stale_hours": config.NAV_STALE_HOURS,
                   "max_pool_age_min": config.MAX_POOL_AGE_MIN,
                   "quote_max_age_sec": config.QUOTE_MAX_AGE_SEC,
                   "max_future_skew_sec": config.MAX_FUTURE_SKEW_SEC,
                   "dev_watch_pct": config.DEV_WATCH_PCT,
                   "dev_abstain_pct": config.DEV_ABSTAIN_PCT,
                   "paper_proposals_enabled": config.PAPER_PROPOSALS_ENABLED,
                   "simulation_notional_usd": config.SIMULATION_NOTIONAL_USD,
                   "max_weight_per_asset": config.MAX_WEIGHT_PER_ASSET,
               },
               "total": len(results), "passed": n_pass,
               "failed": len(results) - n_pass,
               "results": results}
    with open(os.path.join(OUT, "gate_results.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, sort_keys=True)
        f.write("\n")
    lines = ["# Gate §7 — hasil test (Base prototype)",
             "",
             "Policy: %s | Method: %s | Schema: %s" % (
                 config.POLICY_VERSION, config.METHODOLOGY_VERSION,
                 config.SCHEMA_VERSION),
             "",
             "Hasil: **%d/%d PASS**." % (n_pass, len(results)),
             "",
             "| Tes | Hasil | Expected | Actual |",
             "|-----|-------|----------|--------|"]
    for r in results:
        lines.append("| %s | %s | %s | %s |" % (
            r["test"], "PASS" if r["pass"] else "FAIL",
            r["expected"], r["actual"]))
    lines.append("")
    lines.append("Detail per tes (termasuk fixture yang dimodifikasi) ada di "
                "`gate_results.json` dan `fixtures/`. Replay memakai mode "
                "TEST/REPLAY; alert sintetis bukan kejadian pasar live.")
    with open(os.path.join(OUT, "gate_log.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("Gate: %d/%d PASS. Hasil di out/gate_results.json + out/gate_log.md."
          % (n_pass, len(results)))
    return 0 if n_pass == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
